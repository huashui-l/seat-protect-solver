"""Targeted certificate reruns; raw assignments are retained for independent audit."""
import hashlib
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts import benchmark_methods as bench
from src.cg_gurobi import solve

OUT = ROOT / 'build/cpp5-quality/round66-cg900'
OUT.mkdir(exist_ok=True)
IDS = ['d4:wb343_to_wb333:d100', 'forward:100_normal', 'reverse:100_normal',
       'reverse:50_stress', 'd4:rj22_to_nb23:d33', 'd4:nb23_to_rj22:d33']
base = bench._read_json(ROOT / 'config.json')
config = bench._gurobi_config(base, 'cg_gurobi', 900)
config['cg_gurobi']['log'] = True
cases = {c['case_id']: c for c in bench.load_cases(['formal24', 'd4'])}
report = {'budget_seconds': 900, 'frozen_references_unchanged': True,
          'provenance': bench._provenance([cases[c] for c in IDS], ROOT / 'config.json', None, None),
          'config': config, 'cases': []}
report_path = Path('E:/temp/cpp5_quality_round66_cg900.json')
for index, cid in enumerate(IDS):
    print('START', cid, flush=True)
    case = cases[cid]
    new, old, groups = bench._load_case(case)
    started = time.perf_counter()
    raw = solve(new, old, groups, config.get('weights', {}), config)
    elapsed = time.perf_counter() - started
    metrics = bench._metrics(new, old, groups, raw['assigned_seats'], config.get('weights', {}), config)
    row = dict(metrics, case_id=cid, method='cg_gurobi', budget_seconds=900,
               elapsed_seconds=elapsed, error=None, proven_optimal=raw.get('proven_optimal'),
               bound=raw.get('lp_bound'), bound_certified=raw.get('lp_bound_certified'),
               safe_bound=raw.get('safe_bound'), bp_bound=raw.get('bp_bound'),
               bp_bound_certified=bool(raw.get('cabins')) and all(
                   c.get('bp_bound_certified') is True for c in raw['cabins'].values()),
               solver_score=raw.get('total_score'))
    row['objective_error'] = abs(row['score'] - row['solver_score']) if row['score'] is not None else None
    row['optimality_certificate'] = bench.audit_optimality(row)
    saved = dict(raw)
    saved['assigned_seats'] = [{'groupId': k[0], 'hostnum': k[1], 'seatId': v}
                               for k, v in raw['assigned_seats'].items()]
    raw_path = OUT / f'{index:02d}-raw.json'
    raw_path.write_text(json.dumps(bench._json_safe(saved), ensure_ascii=False, indent=2), encoding='utf-8')
    row['raw_path'] = str(raw_path)
    row['raw_sha256'] = bench._sha256(raw_path)
    report['cases'].append(row)
    report_path.write_text(json.dumps(bench._json_safe(report), ensure_ascii=False, indent=2), encoding='utf-8')
    print('DONE', cid, json.dumps(row, ensure_ascii=False), flush=True)
print('ALL_DONE', flush=True)
