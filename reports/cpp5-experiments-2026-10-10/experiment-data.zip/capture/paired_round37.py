import json,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();cases=b.load_cases(['formal24','d4']);work=root/'build/cpp5-quality';config=root/'config.json'
exes={'baseline':work/'gurobi-master-build/seat_protect_cpp.exe','candidate':work/'geometric-matching-checked-build/seat_protect_cpp.exe'}
configs={'baseline':work/'round30_candidate_config.json','candidate':work/'round37_candidate_config.json'}
source_hashes={p.relative_to(root).as_posix():b._sha256(p) for folder in ('native','tests','configs') for p in sorted((root/folder).rglob('*')) if p.is_file() and p.suffix in ('.cpp','.hpp','.ps1','.json','.py')}
report={'cases':[],'baseline_commit':'858e8697d97cbdd1a384c530c603399f4d367d21','candidate_commit':b._git_commit(),'working_tree_dirty':False,'sources_sha256':source_hashes,'executables':{k:{'path':str(v),'sha256':b._sha256(v),'config_path':str(configs[k]),'config_sha256':b._sha256(configs[k])} for k,v in exes.items()},'provenance':b._provenance(cases,config,configs['candidate'],exes['candidate']),'references':b._read_json(work/'references.json'),'build':{'compiler':'MSVC 14.40.33807 x64','flags':'/O2 /EHsc /W4 /std:c++17','highs':'1.15.1','gurobi':'13.0.0','gurobi_dll_sha256':b._sha256(exes['candidate'].parent/'gurobi130.dll'),'highs_dll_sha256':b._sha256(exes['candidate'].parent/'highs.dll'),'seed':0,'master_seeds':{'baseline':[0,1,2,3],'candidate':[0,1,2,3]},'threads_per_master':1},'timing_contract':'5 seconds full process invocation including input loading; independent Python evaluator excluded. No background work after return.'}
path=Path(r'E:/temp/cpp5_quality_round37_paired.json')
for i,case in enumerate(cases):
    order=['baseline','candidate'] if i%2==0 else ['candidate','baseline']
    runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
    reference=report['references']['cases'][case['case_id']]
    for run in runs.values():
        score=reference['reference_score'];run['gap_CG_integer_percent']=max(0,(score-run['score'])/max(1,abs(score)))*100 if score is not None and run.get('complete') and run.get('score') is not None else None
    report['cases'].append({'case_id':case['case_id'],'corpus':case['corpus'],'order':order,'runs':runs,'reference':reference})
    path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(case['case_id'],{k:(r.get('score'),round(r['elapsed_seconds'],3),r.get('complete'),r.get('gap_CG_integer_percent'),r.get('error')) for k,r in runs.items()},flush=True)
report['repeat_validation']={'rule':'Exactly three alternating paired repeats for five fixed high-gap or unstable cases; no optional stopping.', 'runs':[]}
for cid in ['forward:100_edge','forward:full_stress','reverse:150_stress','reverse:full_edge','d4:wb343_to_wb333:d100']:
    case=next(c for c in cases if c['case_id']==cid)
    for r in range(3):
        order=['baseline','candidate'] if r%2==0 else ['candidate','baseline']
        runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
        report['repeat_validation']['runs'].append(dict(case_id=cid,repeat=r+1,runs=runs))
        path.write_text(json.dumps(report,indent=2),encoding='utf-8')
        print('repeat',cid,r+1,{k:(v.get('score'),v.get('complete'),round(v['elapsed_seconds'],3),v.get('error')) for k,v in runs.items()},flush=True)
assert all(b._sha256(root/p)==v for p,v in source_hashes.items())
assert all(b._sha256(exes[k])==report['executables'][k]['sha256'] for k in exes)
assert all(b._sha256(configs[k]) == report['executables'][k]['config_sha256'] for k in configs)
report['benchmark_complete']=True
path.write_text(json.dumps(report,indent=2),encoding='utf-8')
print('DONE',flush=True)
