import json,subprocess,time,hashlib
from pathlib import Path
from src import allocation_evaluator as ev
w=Path('build/cpp5-quality');out=w/'value-pool-diagnostic';exe=w/'value-pool-diagnostic-build/native_rich_repair_probe.exe'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
r=read(out/'result.json');case=read(out/'case.json');cfg=read(out/'config.json');a=read(out/'replay.json')['pool_replay']['assignment']
keys=[(g['groupId'],p['hostnum']) for g in case['groups'] for p in g['psrs']];index={k:i for i,k in enumerate(keys)}
current={int(gid):next(p for p in ps if p['source']=='q0_fallback') for gid,ps in r['merged'].items()}
target=next((int(gid),p) for gid,ps in r['merged'].items() for p in ps if 'value_repair' in p['source'])
requests=[]
for owner in target[1]['conflict_groups']:
    outside=set(target[1]['seat_resources'])
    for gid,p in current.items():
        if gid not in [owner,target[0]]:outside.update(p['seat_resources'])
    requests.append({'group_index':next(i for i,g in enumerate(case['groups']) if g['groupId']==owner),'outside_resources':sorted(outside),'deadline_seconds':0.1})
def run(name,replay):
    path=out/(name+'_replay.json');path.write_text(json.dumps(replay));start=time.perf_counter()
    x=subprocess.run([str(exe.resolve()),str((out/'case.json').resolve()),str((out/'config.json').resolve()),str(path.resolve())],capture_output=True,text=True,timeout=30)
    if x.returncode:raise RuntimeError(x.stderr)
    (out/(name+'_result.json')).write_text(x.stdout)
    return json.loads(x.stdout),time.perf_counter()-start
rel,seconds=run('relocation',{'assignments':list(enumerate(a)),'dynamic_relocation':requests})
print('relocations',seconds,[(v.get('patterns'),list(v.get('elite',{}))) for v in rel],flush=True)
initial=[]
for i,(gid,host) in enumerate(keys):
    blocks=dict(current[gid]['blocked_by_host']).get(host,[])
    row=[i,a[i]]
    if blocks:row.append(blocks[0])
    initial.append(row)
base=[dict(p,group_id=int(gid)) for gid,ps in r['merged'].items() for p in ps]
extra=[]
for v in rel[-1:]:
    for gid,ps in v['elite'].items():
        for p in ps:extra.append(dict(p,group_id=int(gid)))
newseats=read(out/'new.json')['seats'];oldseats=read(out/'old.json')['seats']
report={'probe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'rule':'Fixed complete baseline frame and fixed merged pool; component diagnosis only, not a 5-second solver run.','target_group':target[0],'relocation_seconds':seconds,'added_patterns':len(extra),'runs':[]}
for budget in [1.0,5.0]:
    for name,patterns in [('base',base),('relocated',base+extra)]:
        res,elapsed=run(name+str(budget),{'pattern_context':{'initial':initial,'patterns':patterns,'pairs':[],'restricted_mip':True,'deadline_seconds':budget}})
        assignment=dict(zip(keys,res['state']['assignments']))
        violations,unassigned,detail=ev.count_hard_constraint_violations(newseats,case['groups'],assignment,cfg)
        score,_=ev.calculate_soft_score(newseats,oldseats,case['groups'],assignment,cfg['weights'],cfg)
        report['runs'].append({'pool':name,'budget_seconds':budget,'full_probe_seconds':elapsed,'score':score,'violations':violations,'unassigned':unassigned,'diagnostics':res['diagnostics']})
        print(name,budget,score,violations,unassigned,flush=True)
(out/'relocation_report.json').write_text(json.dumps(report,indent=2))
