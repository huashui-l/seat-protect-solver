import copy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();work=root/'build/cpp5-quality';out=work/'owner-pattern-uptake';out.mkdir(exist_ok=True)
read=b._read_json;captured=[]
def capture(path):
    value=read(path)
    if Path(path).name=='result.json':captured.append(copy.deepcopy(value))
    return value
b._read_json=capture
exes={'baseline':work/'parallel-geometry-delay-build/seat_protect_cpp.exe','candidate':work/'fallback-owner-complements-build/seat_protect_cpp.exe'}
report={'baseline_commit':'f2549cd498e0070855795ecd0ce79e1f4468e278','candidate_commit':b._git_commit(),'executables':{k:{'path':str(v),'sha256':b._sha256(v)} for k,v in exes.items()},'rule':'Diagnostic capture/deepcopy overhead is included in reported elapsed time. These invocations are excluded from promotion timing; use round56/57 for full-process timing.','runs':[]}
for case in b.load_cases(['formal24','d4']):
    if case['case_id'] not in ['forward:100_edge','d4:wb343_to_wb333:d100']:continue
    for kind,exe in exes.items():
        run=b._run_method(case,'cpp_heuristic',5.0,read(root/'config.json'),work/'round56_candidate_config.json',exe)
        assert len(captured)==1
        raw=captured.pop();path=out/(case['case_id'].replace(':','_')+'_'+kind+'.json');path.write_text(json.dumps(raw,indent=2))
        parts=raw.get('cabin_decomposition',{}).get('cabins',{})
        stats={c:v['result']['rich_structured_pattern_generation'].get('owner_pool_patterns',0) for c,v in parts.items()}
        record={'case_id':case['case_id'],'kind':kind,'run':run,'raw_path':str(path),'owner_pool_patterns_by_cabin':stats}
        report['runs'].append(record);print(case['case_id'],kind,run['score'],stats,flush=True)
(out/'provenance.json').write_text(json.dumps(report,indent=2))
