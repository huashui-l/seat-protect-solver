import json,subprocess,time,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
remote=Path('E:/seat_protect_worktrees/remote-smart-heuristic-e273bd9');python=Path('E:/temp/seatprotect-smart-e273-venv/Scripts/python.exe')
out=Path('build/cpp5-quality/remote-smart-e273');path=Path('E:/temp/cpp5_quality_remote_smart_e273.json');report=json.loads(path.read_text())
cases=[c for c in b.load_cases(['formal24','d4']) if c['case_id'] in {'forward:100_edge','reverse:full_edge','d4:wb343_to_wb333:d33','d4:wb343_to_wb333:d100'}]
for i,c in enumerate(cases):
 rawpath=(out/(c['case_id'].replace(':','_')+'.json')).resolve()
 args=[str(python),'-m','src.smart_seat_allocator','--groups',str(c['groups_path'].resolve()),'--old-seatmap',str(c['old_seatmap_path'].resolve()),'--new-seatmap',str(c['new_seatmap_path'].resolve()),'--config',str(Path('config.json').resolve()),'--time-limit','5','--workers','8','--seed','42','--output',str(rawpath)]
 def smart():
  t=time.perf_counter();run=subprocess.run(args,cwd=remote,capture_output=True,text=True,timeout=20);elapsed=time.perf_counter()-t
  raw=json.loads(rawpath.read_text()) if rawpath.exists() else {}
  assignments={tuple(map(int,k.split(','))):v for k,v in raw.get('assigned_seats',{}).items()}
  new,old,groups=b._load_case(c);cfg=b._read_json(Path('config.json'));m=b._metrics(new,old,groups,assignments,cfg['weights'],cfg)
  m.update(full_invocation_seconds=elapsed,solver_function_seconds=raw.get('wall_seconds'),solver_reported_score=raw.get('total_score'),score_error=abs(raw['total_score']-m['score']) if raw.get('total_score') is not None and m.get('score') is not None else None,returncode=run.returncode,error=run.stderr if run.returncode else None,raw_path=str(rawpath),full_5s_eligible=elapsed<=5 and m['complete'])
  return m
 def native():return b._run_method(c,'cpp_heuristic',5,b._read_json(Path('config.json')),Path('build/cpp5-quality/round30_candidate_config.json'),Path('build/cpp5-quality/gurobi-master-build/seat_protect_cpp.exe'))
 methods={'smart':smart,'native':native};order=['native','smart'] if i%2==0 else ['smart','native'];runs={k:methods[k]() for k in order}
 report['cases'].append({'case_id':c['case_id'],'order':order,'runs':runs,'input_hashes':{k:b._sha256(c[k]) for k in ['groups_path','old_seatmap_path','new_seatmap_path']}})
 path.write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(c['case_id'],{k:(v.get('score'),v.get('full_invocation_seconds',v.get('elapsed_seconds')),v.get('complete'),v.get('score_error',v.get('native_score_error')),v.get('error')) for k,v in runs.items()},flush=True)
report['benchmark_complete']=True;path.write_text(json.dumps(report,indent=2),encoding='utf-8')
