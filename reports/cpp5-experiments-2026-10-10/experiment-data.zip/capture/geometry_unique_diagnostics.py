import json,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();work=root/'build/cpp5-quality/geometry-unique-quota-build';out=root/'build/cpp5-quality/geometry-unique-diagnostics';out.mkdir(exist_ok=True)
case=next(c for c in b.load_cases(['formal24']) if c['case_id']=='forward:100_edge')
config=b._read_json(root/'configs/config_native_rich_5s.json');config['input_contract']={'seatmaps_by_direction':{case['direction']:{'old':str(case['old_seatmap_path'].resolve()),'new':str(case['new_seatmap_path'].resolve())}}}
(out/'config.json').write_text(json.dumps(config));data=b._read_json(case['groups_path']);(out/'case.json').write_text(json.dumps(data))
summary={'source_commit':b._git_commit(),'probe_sha256':b._sha256(work/'native_rich_repair_probe.exe'),'selection':'Every group with at least two passengers in forward:100_edge; component 30ms slices, not a full solver quality run.','groups':[]}
for g,group in enumerate(sorted(data['groups'],key=lambda x:x['groupId'])):
    if len(group['psrs'])<2: continue
    replay=out/'replay.json';replay.write_text(json.dumps({'geometry':{'group_index':g,'deadline_seconds':0.03}}))
    run=subprocess.run([str(work/'native_rich_repair_probe.exe'),str(out/'case.json'),str(out/'config.json'),str(replay)],capture_output=True,text=True,timeout=10)
    assert run.returncode==0,run.stderr
    patterns=json.loads(run.stdout)
    signatures={json.dumps([p['assignments'],p['blocked']],sort_keys=True) for p in patterns}
    entry={'group_id':group['groupId'],'size':len(group['psrs']),'generated':len(patterns),'unique':len(signatures)}
    assert entry['generated']==entry['unique'],entry
    summary['groups'].append(entry);print(entry,flush=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2))
