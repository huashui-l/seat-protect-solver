﻿import argparse,copy,json,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--name',required=True);p.add_argument('--exe',default='build/native-organized-final/seat_protect_cpp.exe');p.add_argument('--cases',nargs='*');a=p.parse_args()
root=Path.cwd();exe=(root/a.exe).resolve();cfgpath=(root/a.config).resolve();cases=b.load_cases(['formal24','d4'])
if a.cases:cases=[c for c in cases if c['case_id'] in a.cases]
out=root/'build/cpp5-quality'/a.name;out.mkdir(parents=True,exist_ok=True)
report={'cases':[],'provenance':b._provenance(cases,root/'config.json',cfgpath,exe),'config_path':str(cfgpath),'executable':str(exe)}
for case in cases:
    cfg=b._read_json(cfgpath);cfg.setdefault('input_contract',{}).setdefault('seatmaps_by_direction',{})[case['direction']]={'old':str(case['old_seatmap_path'].resolve()),'new':str(case['new_seatmap_path'].resolve())}
    path=out/case['case_id'].replace(':','_');path.mkdir(exist_ok=True)
    (path/'config.json').write_text(json.dumps(cfg),encoding='utf-8');rawcase=b._read_json(case['groups_path']);rawcase.setdefault('direction',case['direction']);(path/'input.json').write_text(json.dumps(rawcase),encoding='utf-8')
    t=time.perf_counter();run=subprocess.run([str(exe),'--input',str(path/'input.json'),'--config',str(path/'config.json'),'--output',str(path/'raw.json'),'--construction-objective','rich-fast','--time-limit','5','--seed','0'],capture_output=True,text=True,timeout=10);wall=time.perf_counter()-t
    raw=b._read_json(path/'raw.json') if (path/'raw.json').exists() else {};assigned={(int(x['groupId']),int(x['hostnum'])):x['seatId'] for x in raw.get('assignments',[])}
    new,old,groups=b._load_case(case);config=b._read_json(root/'config.json');m=b._metrics(new,old,groups,assigned,config['weights'],config)
    m.update(elapsed_seconds=wall,exit_code=run.returncode,error=run.stderr if run.returncode else None,native_score=raw.get('native_score'),native_score_error=abs(raw['native_score']-m['score']) if raw.get('native_score') is not None and m.get('score') is not None else None,solve_wall_seconds=raw.get('solve_wall_seconds'),raw_path=str(path/'raw.json'))
    row={'case_id':case['case_id'],'corpus':case['corpus'],'direction':case['direction'],'runs':[m]};report['cases'].append(row)
    (out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    diag=raw.get('cabin_decomposition',{}).get('cabins',{});ds=[v['result'] for v in diag.values()] if diag else [raw]
    timings={}
    for d in ds:
        for k,v in d.get('rich_stage_timing',{}).items():timings[k]=round(timings.get(k,0)+v.get('finished',0)-v.get('started',0),3)
    print(a.name,case['case_id'],'score',m.get('score'),'legal',m['complete'],'wall',round(wall,3),'parity',m['native_score_error'],'stages',timings,flush=True)
