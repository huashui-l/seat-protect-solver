import copy, json, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();work=root/'build/cpp5-quality';out=work/'wb-baseline-stage-diagnostics';out.mkdir(exist_ok=True)
read=b._read_json
captured=[]
def capture(path):
    value=read(path)
    if Path(path).name=='result.json': captured.append(copy.deepcopy(value))
    return value
b._read_json=capture
report={'source_commit':'f2549cd498e0070855795ecd0ce79e1f4468e278','executable_sha256':b._sha256(work/'parallel-geometry-delay-build/seat_protect_cpp.exe'),'cases':[]}
case=next(c for c in b.load_cases(['d4']) if c['case_id']=='d4:wb343_to_wb333:d100')
report['rule']='Exactly five baseline runs to inspect stage provenance; keep every run, no optional stopping.'
for repeat in range(5):
    run=b._run_method(case,'cpp_heuristic',5.0,read(root/'config.json'),work/'round40_candidate_config.json',work/'parallel-geometry-delay-build/seat_protect_cpp.exe')
    assert len(captured)==1
    raw=captured.pop()
    target=out/(case['case_id'].replace(':','_')+'_'+str(repeat+1)+'.json')
    target.write_text(json.dumps(raw,indent=2))
    report['cases'].append({'case_id':case['case_id'],'repeat':repeat+1,'run':run,'raw_path':str(target)})
    print(case['case_id'],run['score'],run['elapsed_seconds'],flush=True)
(out/'provenance.json').write_text(json.dumps(report,indent=2))
