import copy, json, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();work=root/'build/cpp5-quality';out=work/'geometry-union-diagnostics';out.mkdir(exist_ok=True)
read=b._read_json
captured=[]
def capture(path):
    value=read(path)
    if Path(path).name=='result.json': captured.append(copy.deepcopy(value))
    return value
b._read_json=capture
report={'source_commit':b._git_commit(),'executable_sha256':b._sha256(work/'geometry-union-build/seat_protect_cpp.exe'),'cases':[]}
for case in b.load_cases(['formal24','d4']):
    if case['case_id'] not in ['forward:100_edge','d4:wb343_to_wb333:d100']: continue
    run=b._run_method(case,'cpp_heuristic',5.0,read(root/'config.json'),work/'round42_candidate_config.json',work/'geometry-union-build/seat_protect_cpp.exe')
    assert len(captured)==1
    raw=captured.pop()
    target=out/(case['case_id'].replace(':','_')+'.json')
    target.write_text(json.dumps(raw,indent=2))
    report['cases'].append({'case_id':case['case_id'],'run':run,'raw_path':str(target)})
    print(case['case_id'],run['score'],run['elapsed_seconds'],flush=True)
(out/'provenance.json').write_text(json.dumps(report,indent=2))
