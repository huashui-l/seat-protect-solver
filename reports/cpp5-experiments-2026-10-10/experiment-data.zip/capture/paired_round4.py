import json,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();cases=b.load_cases(['formal24','d4']);work=root/'build/cpp5-quality';config=root/'config.json'
exes={'baseline':root/'build/cpp5-quality/fallback-reserve-build/seat_protect_cpp.exe','candidate':work/'partial-pool-build/seat_protect_cpp.exe'}
configs={'baseline':root/'configs/config_native_rich_5s.json','candidate':root/'configs/config_native_rich_5s.json'}
source_hashes={p.relative_to(root).as_posix():b._sha256(p) for folder in ('native','tests','configs') for p in sorted((root/folder).rglob('*')) if p.is_file() and p.suffix in ('.cpp','.hpp','.ps1','.json','.py')}
report={'cases':[],'baseline_commit':'fa429eb0131f911fc96e02cdddfd0aecee98f336','candidate_commit':b._git_commit(),'working_tree_dirty':True,'sources_sha256':source_hashes,'executables':{k:{'path':str(v),'sha256':b._sha256(v),'config_path':str(configs[k]),'config_sha256':b._sha256(configs[k])} for k,v in exes.items()},'provenance':b._provenance(cases,config,configs['candidate'],exes['candidate']),'references':b._read_json(work/'references.json'),'build':{'compiler':'MSVC 14.40.33807 x64','flags':'/O2 /EHsc /W4 /std:c++17','highs':'1.15.1','highs_dll_sha256':b._sha256(exes['candidate'].parent/'highs.dll'),'seed':0,'master_seeds':[0,1,2],'threads_per_master':1},'timing_contract':'5 seconds full process invocation including input loading; independent Python evaluator excluded. No background work after return.'}
path=Path(r'E:/temp/cpp5_quality_round4_paired.json')
for i,case in enumerate(cases):
    order=['baseline','candidate'] if i%2==0 else ['candidate','baseline']
    runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
    reference=report['references']['cases'][case['case_id']]
    for run in runs.values():
        score=reference['reference_score'];run['gap_CG_integer_percent']=max(0,(score-run['score'])/max(1,abs(score)))*100 if score is not None and run.get('complete') and run.get('score') is not None else None
    report['cases'].append({'case_id':case['case_id'],'corpus':case['corpus'],'order':order,'runs':runs,'reference':reference})
    path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(case['case_id'],{k:(r.get('score'),round(r['elapsed_seconds'],3),r.get('complete'),r.get('gap_CG_integer_percent'),r.get('error')) for k,r in runs.items()},flush=True)
report['repeat_validation']={'rule':'Exactly three alternating paired repeats for the fallback scheduling bottleneck and the two known full-load time-sensitive cases; no optional stopping.','case_ids':['forward:full_edge','d4:wb343_to_wb333:d33','reverse:full_edge'],'runs':[]}
for case_id in report['repeat_validation']['case_ids']:
    case=next(c for c in cases if c['case_id']==case_id)
    for round_index in range(3):
        order=['baseline','candidate'] if round_index%2==0 else ['candidate','baseline']
        runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
        report['repeat_validation']['runs'].append({'case_id':case_id,'round':round_index+1,'order':order,'runs':runs})
        path.write_text(json.dumps(report,indent=2),encoding='utf-8')
        print('repeat',case_id,round_index+1,{k:(r.get('score'),round(r['elapsed_seconds'],3),r.get('complete'),r.get('error')) for k,r in runs.items()},flush=True)
report['benchmark_complete']=True
path.write_text(json.dumps(report,indent=2),encoding='utf-8')
print('DONE',flush=True)
