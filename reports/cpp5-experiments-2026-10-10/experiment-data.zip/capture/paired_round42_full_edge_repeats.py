import json,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_three_routes as b
root=Path.cwd();cases=b.load_cases(['formal24','d4']);work=root/'build/cpp5-quality';config=root/'config.json'
ids={'forward:full_edge'}
cases=[c for c in cases if c['case_id'] in ids]
exes={'baseline':work/'parallel-geometry-delay-build/seat_protect_cpp.exe','candidate':work/'geometry-union-build/seat_protect_cpp.exe'}
configs={'baseline':work/'round40_candidate_config.json','candidate':work/'round42_candidate_config.json'}
source_hashes={p.relative_to(root).as_posix():b._sha256(p) for folder in ('native','tests','configs') for p in sorted((root/folder).rglob('*')) if p.is_file() and p.suffix in ('.cpp','.hpp','.ps1','.json','.py')}
report={'cases':[],'baseline_commit':'f2549cd498e0070855795ecd0ce79e1f4468e278','candidate_commit':b._git_commit(),'working_tree_dirty':False,'sources_sha256':source_hashes,'executables':{k:{'path':str(v),'sha256':b._sha256(v),'config_path':str(configs[k]),'config_sha256':b._sha256(configs[k])} for k,v in exes.items()},'provenance':b._provenance(cases,config,configs['candidate'],exes['candidate']),'repeat_rule':'Exactly three additional paired repeats of forward:full_edge after observed main/screen variability; retain all results.', 'references':b._read_json(work/'references.json'),'build':{'compiler':'MSVC 14.40.33807 x64','flags':'/O2 /EHsc /W4 /std:c++17','highs':'1.15.1','gurobi':'13.0.0','gurobi_dll_sha256':b._sha256(exes['candidate'].parent/'gurobi130.dll'),'highs_dll_sha256':b._sha256(exes['candidate'].parent/'highs.dll'),'seed':0,'master_seeds':{'baseline':[0,1,2,3,4],'candidate':[0,1,2,3,4]},'threads_per_master':1},'timing_contract':'5 seconds full process invocation including input loading; independent Python evaluator excluded. No background work after return.'}
path=Path(r'E:/temp/cpp5_quality_round42_full_edge_repeats.json')
for i,case in enumerate(cases * 3):
    order=['baseline','candidate'] if i%2==0 else ['candidate','baseline']
    runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
    reference=report['references']['cases'][case['case_id']]
    for run in runs.values():
        score=reference['reference_score'];run['gap_CG_integer_percent']=max(0,(score-run['score'])/max(1,abs(score)))*100 if score is not None and run.get('complete') and run.get('score') is not None else None
    report['cases'].append({'case_id':case['case_id'],'corpus':case['corpus'],'order':order,'runs':runs,'reference':reference,'repeat':i+1})
    path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(case['case_id'],{k:(r.get('score'),round(r['elapsed_seconds'],3),r.get('complete'),r.get('gap_CG_integer_percent'),r.get('error')) for k,r in runs.items()},flush=True)
assert all(b._sha256(configs[k]) == report['executables'][k]['config_sha256'] for k in configs)
assert all(b._sha256(root / path) == digest for path, digest in source_hashes.items())
report['source_hashes_verified']=True
report['benchmark_complete']=True
report['accepted']=False
path.write_text(json.dumps(report,indent=2),encoding='utf-8')
print('DONE',flush=True)
