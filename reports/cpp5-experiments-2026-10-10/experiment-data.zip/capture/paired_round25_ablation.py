import json, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_three_routes as b
root = Path.cwd()
work = root / 'build/cpp5-quality'
ids = ['reverse:100_stress', 'forward:full_stress', 'forward:100_edge']
cases = {c['case_id']: c for c in b.load_cases(['formal24', 'd4'])}
exes = {'baseline': work / 'negative-refinement-build/seat_protect_cpp.exe',
        'candidate': work / 'negative-refinement-build/seat_protect_cpp.exe'}
configs = {'baseline':work/'round17_candidate_config.json','candidate':work/'round24_candidate_config.json'}
config=configs['candidate']
sources = {p.relative_to(root).as_posix(): b._sha256(p) for p in sorted((root/'native').rglob('*'))
           if p.is_file() and p.suffix in ('.cpp', '.hpp', '.ps1')}
report = dict(baseline_commit=b._git_commit(), experiment='negative-refinement enabled versus disabled with identical executable and 0.2 reserve',
    sources_sha256=sources, config_sha256=b._sha256(config), configs={k:dict(path=str(p),sha256=b._sha256(p)) for k,p in configs.items()},
    binaries={k: dict(path=str(p), sha256=b._sha256(p)) for k,p in exes.items()},
    references=b._read_json(work/'references.json'), cases=[],
    rule='Three paired repeats for each of reverse:100_stress, forward:full_stress, forward:100_edge to isolate refinement-dual behavior with the same binary, alternating order; no optional stopping.',
    timing_contract='Full process and input preparation; independent Python audit excluded.')
path = Path('E:/temp/cpp5_quality_round25_ablation.json')
for r in range(3):
    for i, cid in enumerate(ids):
        case = cases[cid]
        order = ['baseline','candidate'] if (i+r)%2==0 else ['candidate','baseline']
        runs = {k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(root/'config.json'),configs[k],exes[k]) for k in order}
        report['cases'].append(dict(case_id=cid, repeat=r+1, runs=runs,
            provenance=b._provenance([case],root/'config.json',config,exes['candidate'])))
        path.write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(r+1,cid,{k:(v.get('score'),v.get('complete'),v.get('native_score_error'),round(v['elapsed_seconds'],3),v.get('error')) for k,v in runs.items()},flush=True)
assert all(b._sha256(p)==report['configs'][k]['sha256'] for k,p in configs.items())
assert all(b._sha256(root/p)==sha for p,sha in sources.items())
report['benchmark_complete']=True
path.write_text(json.dumps(report,indent=2),encoding='utf-8')
print('DONE',flush=True)
