import contextlib
import hashlib
import json
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_methods as b

root = Path.cwd()
work = root / 'build/cpp5-quality'
capture = work / 'round71-full-edge-capture'
capture.mkdir(exist_ok=True)
case = next(c for c in b.load_cases(['formal24']) if c['case_id'] == 'forward:full_edge')
config = work / 'round56_candidate_config.json'
exes = {'baseline': work/'fallback-owner-complements-build/seat_protect_cpp.exe',
        'candidate': work/'dfs-undo-build/seat_protect_cpp.exe'}
report = {'purpose': 'Fixed three paired follow-up captures of the full-edge quality regression; raw assignments and stage diagnostics retained. Not a promotion benchmark.',
          'candidate_commit': b._git_commit(), 'provenance': b._provenance([case], root/'config.json', config, exes['candidate']),
          'executables': {k: {'path':str(v),'sha256':b._sha256(v)} for k,v in exes.items()}, 'runs': []}
for repeat in range(3):
    order = ['baseline','candidate'] if repeat%2 == 0 else ['candidate','baseline']
    for method in order:
        folder = capture / f'{repeat+1}-{method}'
        folder.mkdir(exist_ok=False)
        @contextlib.contextmanager
        def retain(**kwargs):
            yield str(folder)
        with patch.object(b.tempfile, 'TemporaryDirectory', retain):
            metrics = b._run_method(case, 'cpp_heuristic', 5.0, b._read_json(root/'config.json'), config, exes[method])
        assert metrics['complete'] and metrics['violations']==0 and metrics['unassigned']==0 and not metrics['error']
        assert metrics['native_score_error'] <= 1e-6 and metrics['elapsed_seconds'] <= 5
        result = folder/'result.json'
        report['runs'].append({'repeat':repeat+1,'method':method,'metrics':metrics,'raw_output':str(result),
                               'raw_sha256':b._sha256(result)})
        Path('E:/temp/cpp5_quality_round71_full_edge_capture.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(repeat+1,method,metrics['score'],round(metrics['elapsed_seconds'],3),flush=True)
report['capture_complete'] = True
Path('E:/temp/cpp5_quality_round71_full_edge_capture.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
