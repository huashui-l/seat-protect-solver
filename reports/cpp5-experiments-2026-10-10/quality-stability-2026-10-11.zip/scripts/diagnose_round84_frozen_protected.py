import copy,json,subprocess,time,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_methods as b
root=Path.cwd();work=root/'build/cpp5-quality';dest=work/'round84-frozen-protected';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
exes={k:work/v/'native_rich_repair_probe.exe' for k,v in {'baseline':'fixed-infant-score-build','candidate':'relocation-history-build'}.items()}
cases=b.load_cases(['formal24','d4']);report={'scope':'Frozen final legal economy states and elite pools from round76; extra 2s protected repair with retained relocation history diagnostic only, not 5s end-to-end acceptance','stage_budget_seconds':2.0,'executables':{k:{'path':str(p),'sha256':sha(p)} for k,p in exes.items()},'cases':[]}
for i in range(3):
 source=work/'round76-baseline-capture'/str(i);raw=b._read_json(source/'result.json');payload=b._read_json(source/'case.json');native=b._read_json(source/'native_config.json');e=raw['cabin_decomposition']['cabins']['Economy']['result']
 source_case=next(c for c in cases if c['direction']==payload['direction'] and b._read_json(c['groups_path']).get('caseId')==payload['caseId'])
 new=b._read_json(source_case['new_seatmap_path']);old=b._read_json(source_case['old_seatmap_path'])
 assigned={(x['groupId'],x['hostnum']):x['seatId'] for x in e['assignments']};groups=[]
 for g in payload['groups']:
  ps=[p for p in g['psrs'] if (g['groupId'],p['hostnum']) in assigned]
  if ps:groups.append({**g,'psrs':ps})
 keys=[(g['groupId'],p['hostnum']) for g in groups for p in g['psrs']];indexes={key:i for i,key in enumerate(keys)};initial=[];occupied=set(assigned.values())
 for g in groups:
  gid=g['groupId'];signature=sorted((p['hostnum'],assigned[gid,p['hostnum']]) for p in g['psrs'])
  current=next(p for p in e['rich_elite_store'][str(gid)] if sorted(map(tuple,p['assignments']))==signature and not (set(p['blocked_seats'])&occupied))
  blocks=dict(current['blocked_by_host'])
  for p in g['psrs']:
   entry=[indexes[gid,p['hostnum']],assigned[gid,p['hostnum']]]
   if p.get('mandatoryRule',{}).get('needSingleSideEmpty')=='Y':entry+=blocks[p['hostnum']][:1]
   initial.append(entry)
 passengers=[p for g in groups for p in g['psrs']];initial.sort(key=lambda x:passengers[x[0]].get('needCared')=='Y' or native.get('ssr_rules',{}).get(passengers[x[0]].get('ssr',''),{}).get('requires_caregiver',False))
 patterns=[dict(group_id=int(gid),**pattern) for gid,entries in e['rich_elite_store'].items() for pattern in entries]
 config=copy.deepcopy(native);config['algorithm'].update(enable_protected_multigroup_pattern_mip=True,enable_priority_multigroup_pattern_mip=True,enable_tail_exchange=True);config['input_contract']={'seatmaps_by_direction':{'diagnostic':{'old':'old.json','new':'new.json'}}}
 folder=dest/str(i);folder.mkdir(exist_ok=True)
 for name,value in {'case.json':{'caseId':payload['caseId'],'direction':'diagnostic','groups':groups},'config.json':config,'old.json':old,'new.json':new,'replay.json':{'pattern_context':dict(initial=initial,patterns=patterns,pairs=[],protected_mip=True,protected_stage=True,deadline_seconds=2.0)}}.items():(folder/name).write_text(json.dumps(value),encoding='utf-8')
 before=b._metrics(new['seats'],old['seats'],groups,assigned,config['weights'],config);assert before['complete'];entry={'case_id':source_case['case_id'],'source_result_sha256':sha(source/'result.json'),'before':before,'inputs_sha256':{p.name:sha(p) for p in folder.iterdir() if p.is_file()},'repeats':[]}
 for repeat in range(3):
  versions=['baseline','candidate'];offset=(i+repeat)%2;order=versions[offset:]+versions[:offset];runs={}
  for v in order:
   start=time.perf_counter();r=subprocess.run([str(exes[v]),str(folder/'case.json'),str(folder/'config.json'),str(folder/'replay.json')],capture_output=True,text=True);elapsed=time.perf_counter()-start
   assert r.returncode==0,(v,r.stderr);result=json.loads(r.stdout);(folder/(str(repeat)+'-'+v+'.json')).write_text(r.stdout,encoding='utf-8');assignment=dict(zip(keys,result['state']['assignments']));metrics=b._metrics(new['seats'],old['seats'],groups,assignment,config['weights'],config);assert metrics['complete'] and metrics['score']+1e-7>=before['score'];runs[v]={'elapsed_seconds':elapsed,**metrics,'diagnostics':result['diagnostics'],'output_sha256':hashlib.sha256(r.stdout.encode()).hexdigest()}
  entry['repeats'].append({'repeat':repeat+1,'order':order,'runs':runs});print(source_case['case_id'],repeat+1,{v:(x['score'],x['diagnostics']['components_tested'],round(x['elapsed_seconds'],3)) for v,x in runs.items()},flush=True)
 report['cases'].append(entry);(dest/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
report['complete']=True;(dest/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
