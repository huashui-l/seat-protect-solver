import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_methods as b

root = Path.cwd()
work = root/'build/cpp5-quality'
out = work/'round70-dfs-fixed-nodes'
out.mkdir(exist_ok=True)
probes = {'baseline_constructor': work/'rebuild-shared-dp-build/native_rich_repair_probe.exe',
          'candidate': work/'dfs-undo-build/native_rich_repair_probe.exe'}
report = {'purpose': 'Fixed-node construction equivalence diagnosis with nonbinding time budgets; not a 5s benchmark. Baseline constructor is unchanged in the shared-DP build and VND is disabled.',
          'probes': {k: {'path': str(v), 'sha256': b._sha256(v)} for k,v in probes.items()}, 'cases': []}
cases = {c['case_id']: c for c in b.load_cases(['formal24','d4'])}
for index,cid in enumerate(['forward:full_edge','d4:wb343_to_wb333:d100']):
    case = cases[cid]
    native_case = b._read_json(case['groups_path'])
    native_case.setdefault('direction', case['direction'])
    input_path = out/f'{index}-case.json'
    input_path.write_text(json.dumps(native_case),encoding='utf-8')
    config = b._read_json(root/'config.json')
    config['algorithm'].update(business_time_limit_seconds=120, adaptive_stage_budgets=False,
        construction_time_budget=60, small_group_dfs_time_limit=20, stage3_time_budget=60,
        small_group_dfs_node_limit=20000, final_repair_time_limit=10)
    config['input_contract'] = {'seatmaps_by_direction': {case['direction']: {
        'old': str(case['old_seatmap_path']), 'new': str(case['new_seatmap_path'])}}}
    cfg = out/f'{index}-config.json'
    cfg.write_text(json.dumps(config),encoding='utf-8')
    replay = out/f'{index}-replay.json'
    replay.write_text(json.dumps({'assignments': [], 'construction_pipeline': True,
                                  'pipeline_vnd': False, 'pipeline_structured': False}),encoding='utf-8')
    row = {'case_id': cid, 'runs': {}}
    for k,probe in probes.items():
        started = time.perf_counter()
        p = subprocess.run([str(probe), str(input_path), str(cfg), str(replay)],capture_output=True,text=True,timeout=180)
        assert p.returncode == 0, p.stderr
        raw = json.loads(p.stdout)
        rawpath=out/f'{index}-{k}.json'
        rawpath.write_text(json.dumps(raw,indent=2),encoding='utf-8')
        row['runs'][k] = {'seconds': time.perf_counter()-started, 'result': raw,
                          'raw_path': str(rawpath), 'raw_sha256': b._sha256(rawpath)}
    row['exact_output_equal'] = row['runs']['baseline_constructor']['result'] == row['runs']['candidate']['result']
    report['cases'].append(row)
    Path('E:/temp/cpp5_quality_round70_dfs_nodes.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(cid,'equal',row['exact_output_equal'],{k:v['seconds'] for k,v in row['runs'].items()},flush=True)
report['complete']=True
Path('E:/temp/cpp5_quality_round70_dfs_nodes.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
