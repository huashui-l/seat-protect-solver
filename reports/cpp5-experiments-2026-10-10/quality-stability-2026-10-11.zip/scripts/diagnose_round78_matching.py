import copy,json,subprocess,time,hashlib,random,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from tests.test_native_rich_lns import NativeRichLnsTests
root=Path.cwd();work=root/'build/cpp5-quality';dest=work/'round78-matching-diagnostic';dest.mkdir(exist_ok=True)
NativeRichLnsTests.setUpClass();t=NativeRichLnsTests();case=t.synthetic([(20,{}) for _ in range(8)])
config=copy.deepcopy(t.config);config['input_contract']={'seatmaps_by_direction':{'public-test':{'old':'old.json','new':'new.json'}}}
report={'purpose':'Nonbinding-deadline isolated matching equivalence and speed diagnostic; not end-to-end acceptance','calls_per_invocation':1500,'pairs_per_size':3,'sizes':[]}
for n in [2,4,6,8]:
 c=t.synthetic([(20,{}) for _ in range(n)]);folder=dest/str(n);folder.mkdir(exist_ok=True)
 ids=[x['seatId'] for x in c['newSeatmapData']['seats']];rng=random.Random(7811+n)
 calls=[dict(group_index=0,seats=rng.sample(ids,n),released=ids,scores=[]) for _ in range(1500)]
 for name,value in {'case.json':{'caseId':c['id'],'direction':'public-test','groups':c['groupsData']},'old.json':c['oldSeatmapData'],'new.json':c['newSeatmapData'],'config.json':config,'replay.json':{'pattern_context':{'initial':[[i,ids[i]] for i in range(n)],'lns_matching':calls,'deadline_seconds':120}}}.items():(folder/name).write_text(json.dumps(value),encoding='utf-8')
 out={'group_size':n,'pairs':[],'inputs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file()}}
 for repeat in range(3):
  runs={};outputs={}
  for v in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   exe=work/({'baseline':'fixed-infant-score-build','candidate':'lns-score-matrix-build'}[v])/'native_rich_repair_probe.exe'
   start=time.perf_counter();r=subprocess.run([str(exe),str(folder/'case.json'),str(folder/'config.json'),str(folder/'replay.json')],capture_output=True);elapsed=time.perf_counter()-start
   assert r.returncode==0,r.stderr.decode(errors='replace');outputs[v]=r.stdout;runs[v]={'seconds':elapsed,'output_sha256':hashlib.sha256(r.stdout).hexdigest(),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
  assert outputs['baseline']==outputs['candidate'];out['pairs'].append(runs)
 report['sizes'].append(out);print(n,[(round(x['baseline']['seconds'],4),round(x['candidate']['seconds'],4)) for x in out['pairs']],flush=True)
report['all_outputs_exactly_equal']=True
(dest/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
