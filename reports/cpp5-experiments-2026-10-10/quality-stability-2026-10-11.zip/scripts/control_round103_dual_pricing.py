import hashlib
import json
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from tests.test_native_rich_pattern_context import NativeRichPatternContextTests

original = subprocess.run
evidence = {}
sha = lambda data: hashlib.sha256(data).hexdigest()

def compare(args, **kwargs):
    replay_path = Path(args[-1])
    replay = json.loads(replay_path.read_text(encoding='utf-8'))
    mode = replay['pattern_context']
    if mode.get('dual_pool_pricing') and mode['deadline_seconds'] > 0:
        control = json.loads(json.dumps(replay))
        control['pattern_context']['dual_pool_pricing'] = False
        control_path = replay_path.with_name('control.json')
        control_path.write_text(json.dumps(control), encoding='utf-8')
        baseline = original([*args[:-1], str(control_path)], **kwargs)
        candidate = original(args, **kwargs)
        assert baseline.returncode == candidate.returncode == 0
        before, after = json.loads(baseline.stdout), json.loads(candidate.stdout)
        assert before['state']['assignments'] == ['2A', '1A']
        assert after['state']['assignments'] == ['1A', '2A']
        assert before['diagnostics']['score_improvement'] == 0
        assert after['diagnostics']['score_improvement'] > 0
        evidence.update(purpose='Matched input/config/binary/2s budget; only the dual pool discovery flag differs.',
            executable_sha256=sha(Path(args[0]).read_bytes()),
            input_sha256=sha(Path(args[1]).read_bytes()), config_sha256=sha(Path(args[2]).read_bytes()),
            baseline_replay=control, candidate_replay=replay, baseline=before, candidate=after)
        return candidate
    return original(args, **kwargs)

suite = unittest.TestSuite([NativeRichPatternContextTests(
    'test_dual_pool_discovers_missing_exchange_and_honors_expired_deadline')])
with patch('subprocess.run', compare):
    result = unittest.TextTestRunner().run(suite)
assert result.wasSuccessful() and evidence
Path('build/cpp5-quality/round103-controlled-pricing.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
print('PASS matched control: original pool unchanged; dual discovery supplies the missing exchange and improves score')
