import hashlib
import json
import math
import statistics
from pathlib import Path

path = Path('E:/temp/cpp5_quality_round92_paired.json')
report = json.loads(path.read_text(encoding='utf-8'))
source = Path(report['references']['source'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source) == report['references']['sha256']
old = json.loads(source.read_text(encoding='utf-8'))
checked, sources = {}, {}
for key, metadata in old['provenance'].items():
    if key == 'source_1':
        continue  # Historical C++ results are outside this exact-route reference audit.
    file = Path(metadata['path'])
    assert sha(file) == metadata['sha256']
    sources[key] = dict(path=str(file), sha256=metadata['sha256'])
    for name, digest in metadata['run_provenance']['files_sha256'].items():
        file = Path('config.json') if name == 'config' else Path(name)
        if name == 'config' or (file.is_absolute() and '/data/' in file.as_posix().replace('//', '/')):
            assert sha(file) == digest
            checked[str(file.resolve())] = digest
current = {c['case_id']: c for c in report['cases']}
rows, changes = [], []
for case in old['cases']:
    legal = [run for run in case['runs']
             if run['method'] in ['cg_gurobi', 'direct_gurobi'] and run['complete']
             and run['violations'] == run['unassigned'] == 0 and not run['error']
             and run['score'] is not None and math.isfinite(run['score'])
             and (run['method'] != 'direct_gurobi' or run['objective_error'] is not None
                  and run['objective_error'] <= 1e-6)]
    assert legal, case['case_id']
    best = max(legal, key=lambda run: run['score'])
    cid = case['case_id']
    gaps = {v: max(0, best['score'] - current[cid]['runs'][v]['score']) / max(1, abs(best['score'])) * 100
            for v in ['baseline', 'candidate']}
    frozen = report['references']['cases'][cid]['reference_score']
    if frozen is None or abs(best['score'] - frozen) > 1e-9:
        changes.append(dict(case_id=cid, frozen_CG_score=frozen, exact_route_best_score=best['score'],
                            candidate_gap_percent=gaps['candidate']))
    rows.append(dict(case_id=cid, reference_score=best['score'], reference_method=best['method'],
                     reference_budget_seconds=best['budget_seconds'], source=best['source'],
                     reference_kind='complete_legal_integer_incumbent', gap_percent=gaps))
assert len(rows) == 40
assert report['references'] == json.loads(Path('build/cpp5-quality/references.json').read_text(encoding='utf-8'))
report['best_known_exact_route_reference_audit'] = dict(source=str(source), source_sha256=sha(source),
    sources=sources, checked_input_and_base_config_count=len(checked), checked_input_and_base_config_sha256=checked,
    scope='Historical complete legal integer scores from CG/direct at 150/600s; excludes incomplete runs and all bounds. Frozen CG benchmark references unchanged. Not a global optimality certificate.',
    versions={v: dict(reference_count=40, mean_gap_percent=statistics.mean(c['gap_percent'][v] for c in rows),
                      worst_gap_percent=max(c['gap_percent'][v] for c in rows),
                      gap_le_2_count=sum(c['gap_percent'][v] <= 2 for c in rows)) for v in ['baseline', 'candidate']},
    cases=rows, changes_from_frozen_CG_references=changes)
path.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report['best_known_exact_route_reference_audit']['versions'], indent=2))
