import contextlib
import json
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_methods as b

root = Path.cwd()
work = root / 'build/cpp5-quality'
capture = work / 'round96-baseline-capture'
capture.mkdir(exist_ok=True)
ids = ['d4:nb23_to_rj22:d100', 'd4:wb343_to_wb333:d100', 'forward:full_edge', 'reverse:full_edge', 'forward:full_stress', 'd4:wb343_to_wb333:d33']
all_cases = {c['case_id']: c for c in b.load_cases(['formal24', 'd4'])}
cases = [all_cases[cid] for cid in ids]
config = work / 'round56_candidate_config.json'
exe = work / 'parallel-cabins-build/seat_protect_cpp.exe'
report = {'purpose': 'One retained baseline capture per newly unstable case; diagnosis only, not a promotion benchmark.',
          'algorithm_commit': '4e19614a2e7e058c2fcf1e45d325cceb8b354ca0',
          'provenance': b._provenance(cases, root/'config.json', config, exe), 'runs': []}
for index, case in enumerate(cases):
    folder = capture / str(index)
    folder.mkdir(exist_ok=False)
    @contextlib.contextmanager
    def retain(**kwargs):
        yield str(folder)
    with patch.object(b.tempfile, 'TemporaryDirectory', retain):
        metrics = b._run_method(case, 'cpp_heuristic', 5.0, b._read_json(root/'config.json'), config, exe)
    assert metrics['complete'] and metrics['violations'] == metrics['unassigned'] == 0 and not metrics['error']
    assert metrics['native_score_error'] <= 1e-6 and metrics['elapsed_seconds'] <= 5
    result = folder/'result.json'
    report['runs'].append({'case_id': case['case_id'], 'metrics': metrics,
                           'raw_output': str(result), 'raw_sha256': b._sha256(result)})
    Path('E:/temp/cpp5_quality_round96_baseline_capture.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(case['case_id'], metrics['score'], round(metrics['elapsed_seconds'], 3), flush=True)
report['capture_complete'] = True
Path('E:/temp/cpp5_quality_round96_baseline_capture.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
