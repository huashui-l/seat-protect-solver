import contextlib
import json
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from scripts import benchmark_methods as b

root = Path.cwd()
work = root / 'build/cpp5-quality'
capture = work / 'round108-rj-capture'
capture.mkdir(exist_ok=False)
case = next(c for c in b.load_cases(['formal24', 'd4']) if c['case_id'] == 'd4:rj22_to_nb23:d100')
config = work / 'round56_candidate_config.json'
versions = {'pre_dual': ('4e19614a2e7e058c2fcf1e45d325cceb8b354ca0', 'parallel-cabins-build'),
            'accepted_dual': ('fbb3909626df697a9276f0c35d9916ba49f9df71', 'dual-priced-pool-build'),
            'base_companion': (b._git_commit(), 'dual-base-companion-build')}
report = {'purpose': 'Same-case diagnostic captures of retained versions to locate the RJ d100 score difference; not promotion evidence.',
          'case_id': case['case_id'], 'runs': []}
for name, (commit, build) in versions.items():
    folder = capture / name
    folder.mkdir()
    exe = work / build / 'seat_protect_cpp.exe'
    @contextlib.contextmanager
    def retain(**kwargs):
        yield str(folder)
    with patch.object(b.tempfile, 'TemporaryDirectory', retain):
        metrics = b._run_method(case, 'cpp_heuristic', 5.0, b._read_json(root / 'config.json'), config, exe)
    assert metrics['complete'] and not metrics['error'] and metrics['violations'] == metrics['unassigned'] == 0
    assert metrics['native_score_error'] <= 1e-6 and metrics['elapsed_seconds'] <= 5
    raw = folder / 'result.json'
    report['runs'].append(dict(version=name, algorithm_commit=commit, metrics=metrics,
        provenance=b._provenance([case], root / 'config.json', config, exe), raw_output=str(raw), raw_sha256=b._sha256(raw)))
    print(name, metrics['score'], metrics['elapsed_seconds'], flush=True)
report['capture_complete'] = True
Path('E:/temp/cpp5_quality_round108_rj_capture.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
