import json
import math
import statistics
from pathlib import Path

path = Path('E:/temp/cpp5_quality_round95_paired.json')
report = json.loads(path.read_text(encoding='utf-8'))
assert report['benchmark_complete'] and report['source_hashes_verified']
main = report['cases']
repeats = report['repeat_validation']['runs']
assert len(main) == 40 and len(repeats) == 18
all_runs = [run for case in main + repeats for run in case['runs'].values()]

def valid(run):
    return (run['complete'] and not run.get('error') and run['violations'] == run['unassigned'] == 0
            and run['native_score_error'] is not None and run['native_score_error'] <= 1e-6
            and math.isfinite(run['score']) and run['elapsed_seconds'] <= 5)

summary = {'invocations': len(all_runs), 'complete_legal_score_parity_under_5s': sum(map(valid, all_runs)),
           'main_raw_score_delta': sum(c['runs']['candidate']['score'] - c['runs']['baseline']['score'] for c in main),
           'repeat_raw_score_delta': sum(c['runs']['candidate']['score'] - c['runs']['baseline']['score'] for c in repeats),
           'versions': {}, 'repeated_case_means': {}}
for version in ['baseline', 'candidate']:
    runs = [c['runs'][version] for c in main + repeats]
    gaps = [c['runs'][version]['gap_CG_integer_percent'] for c in main
            if valid(c['runs'][version]) and c['runs'][version]['gap_CG_integer_percent'] is not None]
    summary['versions'][version] = dict(max_elapsed_seconds=max(r['elapsed_seconds'] for r in runs),
        mean_gap_percent=statistics.mean(gaps), worst_gap_percent=max(gaps),
        gap_le_2_count=sum(g <= 2 for g in gaps), reference_count=len(gaps))
for cid in dict.fromkeys(c['case_id'] for c in repeats):
    cases = [c for c in main + repeats if c['case_id'] == cid]
    scores = {v: statistics.mean(c['runs'][v]['score'] for c in cases) for v in ['baseline', 'candidate']}
    summary['repeated_case_means'][cid] = {**scores, 'delta': scores['candidate'] - scores['baseline'],
                                         'pairs_including_main': len(cases)}
rows = []
for case in main:
    pairs = [case] + [c for c in repeats if c['case_id'] == case['case_id']]
    scores = {v: statistics.mean(c['runs'][v]['score'] for c in pairs) for v in ['baseline', 'candidate']}
    reference = case['reference']['reference_score']
    gaps = {v: max(0, reference - score) / max(1, abs(reference)) * 100 if reference is not None else None
            for v, score in scores.items()}
    rows.append(dict(case_id=case['case_id'], pairs=len(pairs), scores=scores, gaps=gaps))
summary['equal_case_averages'] = dict(
    rule='Equal case weight: average main plus all three preselected repeats per repeated case; other cases use main.',
    raw_score_delta=sum(c['scores']['candidate'] - c['scores']['baseline'] for c in rows),
    versions={v: dict(mean_gap_percent=statistics.mean(c['gaps'][v] for c in rows if c['gaps'][v] is not None),
                      worst_gap_percent=max(c['gaps'][v] for c in rows if c['gaps'][v] is not None),
                      gap_le_2_count=sum(c['gaps'][v] <= 2 for c in rows if c['gaps'][v] is not None))
              for v in ['baseline', 'candidate']}, cases=rows)
known_source=Path(report['best_known_reference_source']['path'])
import hashlib
assert hashlib.sha256(known_source.read_bytes()).hexdigest() == report['best_known_reference_source']['sha256']
known={c['case_id']:c['reference_score'] for c in json.loads(known_source.read_text())['best_known_exact_route_reference_audit']['cases']}
summary['best_known_exact_integer']={}
for version in ['baseline','candidate']:
    gaps=[max(0,known[c['case_id']]-c['runs'][version]['score'])/max(1,abs(known[c['case_id']]))*100 for c in main]
    averaged=[max(0,known[c['case_id']]-c['scores'][version])/max(1,abs(known[c['case_id']]))*100 for c in rows]
    summary['best_known_exact_integer'][version]={'reference_count':len(gaps),'mean_gap_percent':statistics.mean(gaps),'worst_gap_percent':max(gaps),'gap_le_2_count':sum(g<=2 for g in gaps),'equal_case_mean_gap_percent':statistics.mean(averaged),'equal_case_worst_gap_percent':max(averaged),'equal_case_gap_le_2_count':sum(g<=2 for g in averaged)}
report['full_validation_summary'] = summary
path.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
