import json,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_methods as b
root=Path.cwd();cases=b.load_cases(['formal24','d4']);work=root/'build/cpp5-quality';config=root/'config.json'
ids={'reverse:50_edge','forward:full_normal','forward:100_edge','reverse:100_stress','reverse:150_stress','d4:nb33_to_wb242:d100','d4:wb343_to_wb333:d100','d4:wb343_to_wb333:d33','reverse:full_edge','reverse:full_normal','forward:full_stress','forward:full_edge'}
# Full Formal24+D4 paired validation, all 40 cases.
exes={'baseline':work/'fallback-owner-complements-build/seat_protect_cpp.exe','candidate':work/'dfs-pattern-handoff-build/seat_protect_cpp.exe'}
configs={'baseline':work/'round56_candidate_config.json','candidate':work/'round56_candidate_config.json'}
source_hashes={p.relative_to(root).as_posix():b._sha256(p) for folder in ('native','tests','configs') for p in sorted((root/folder).rglob('*')) if p.is_file() and p.suffix in ('.cpp','.hpp','.ps1','.json','.py')}
report={'cases':[],'baseline_commit':'03d36a842251bd4d927b4fd20c8c37ee761f43ad','candidate_commit':b._git_commit(),'working_tree_dirty':False,'sources_sha256':source_hashes,'executables':{k:{'path':str(v),'sha256':b._sha256(v),'config_path':str(configs[k]),'config_sha256':b._sha256(configs[k])} for k,v in exes.items()},'provenance':b._provenance(cases,config,configs['candidate'],exes['candidate']),'references':b._read_json(work/'references.json'),'build':{'compiler':'MSVC 14.40.33807 x64','flags':'/O2 /EHsc /W4 /std:c++17','highs':'1.15.1','gurobi':'13.0.0','gurobi_dll_sha256':b._sha256(exes['candidate'].parent/'gurobi130.dll'),'highs_dll_sha256':b._sha256(exes['candidate'].parent/'highs.dll'),'seed':0,'master_seeds':{'baseline':[0,1,2,3,4],'candidate':[0,1,2,3,4]},'threads_per_master':1},'timing_contract':'5 seconds full process invocation including input loading; independent Python evaluator excluded. No background work after return.'}
report['experiment']='Retain strict-improvement complete-group DFS patterns in the existing supplemental pool; no config changes'
report['certified_upper_source']={'path':'E:/temp/cpp5_quality_round66_cg900.json','sha256':b._sha256(Path('E:/temp/cpp5_quality_round66_cg900.json'))}
upper={c['case_id']:min(v for v in [c['bound'],c['bp_bound']] if v is not None) for c in b._read_json(Path(report['certified_upper_source']['path']))['cases'] if c['bound_certified'] and c['bp_bound_certified']}
path=Path(r'E:/temp/cpp5_quality_round73_paired.json')
for i,case in enumerate(cases):
    order=['baseline','candidate'] if i%2==0 else ['candidate','baseline']
    runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
    reference=report['references']['cases'][case['case_id']]
    for run in runs.values():
        score=reference['reference_score'];run['gap_CG_integer_percent']=max(0,(score-run['score'])/max(1,abs(score)))*100 if score is not None and run.get('complete') and run.get('score') is not None else None
    for run in runs.values():
        ub=upper.get(case['case_id']);run['gap_certified_upper_percent']=max(0,(ub-run['score'])/max(1,abs(ub)))*100 if ub is not None and run.get('complete') and run.get('score') is not None else None
    report['cases'].append({'case_id':case['case_id'],'corpus':case['corpus'],'order':order,'runs':runs,'reference':reference})
    path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(case['case_id'],{k:(r.get('score'),round(r['elapsed_seconds'],3),r.get('complete'),r.get('gap_CG_integer_percent'),r.get('error')) for k,r in runs.items()},flush=True)
report['repeat_validation']={'rule':'Exactly three alternating paired repeats of each of six preselected difficult/stress cases; no optional stopping.','runs':[]}
for cid in ['forward:100_edge','d4:wb343_to_wb333:d100','d4:nb33_to_wb242:d100','reverse:full_edge','reverse:full_normal','forward:full_stress']:
    case=next(c for c in cases if c['case_id']==cid)
    for repeat in range(3):
        order=['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']
        runs={k:b._run_method(case,'cpp_heuristic',5.0,b._read_json(config),configs[k],exes[k]) for k in order}
        report['repeat_validation']['runs'].append(dict(case_id=cid,repeat=repeat+1,runs=runs))
        path.write_text(json.dumps(report,indent=2),encoding='utf-8')
        print('repeat',cid,repeat+1,{k:(r.get('score'),r.get('complete'),round(r['elapsed_seconds'],3)) for k,r in runs.items()},flush=True)
assert all(b._sha256(configs[k]) == report['executables'][k]['config_sha256'] for k in configs)
assert all(b._sha256(root / path) == digest for path, digest in source_hashes.items())
report['source_hashes_verified']=True
report['benchmark_complete']=True
report['accepted']=False
path.write_text(json.dumps(report,indent=2),encoding='utf-8')
print('DONE',flush=True)
