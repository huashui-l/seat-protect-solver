import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
work = root / 'build/cpp5-quality'
candidate = work / 'combined-pattern-pool-build'
baseline = work / 'parallel-protected-tail-build'
destination = work / 'combined-pool-baseline-probe-build'
destination.mkdir(exist_ok=True)
build = (root / 'native/build_native_solver_pipeline.ps1').read_text(encoding='utf-8-sig')
block = re.search(r'\$SolverObjects = @\((.*?)\)', build, re.S).group(1)
names = re.findall(r"'([^']+)'", block) + ['native_rich_repair_probe']
objects = [(baseline if name == 'native_rich_restricted_mip' else candidate) / (name + '.obj')
           for name in names]
assert all(path.is_file() for path in objects)
vswhere = Path(os.environ['ProgramFiles(x86)']) / 'Microsoft Visual Studio/Installer/vswhere.exe'
installation = subprocess.check_output([str(vswhere), '-latest', '-products', '*', '-requires',
    'Microsoft.VisualStudio.Component.VC.Tools.x86.x64', '-property', 'installationPath'], text=True).strip()
developer = Path(installation) / 'Common7/Tools/VsDevCmd.bat'
script = destination / 'link_baseline_probe.cmd'
executable = destination / 'native_rich_repair_probe.exe'
script.write_text('@echo off\ncall "' + str(developer) + '" -arch=x64 -host_arch=x64 >nul\n'
    + 'if errorlevel 1 exit /b 1\nlink /nologo ' + ' '.join('"' + str(p) + '"' for p in objects)
    + ' /LIBPATH:"E:/seat_protect/code_v5/outputs/research/toolchains/highs-1.15.1-x86_64-windows-mit/lib"'
    + ' highs.lib "C:/gurobi1300/win64/lib/gurobi130.lib" /OUT:"' + str(executable) + '"\n', encoding='utf-8')
result = subprocess.run(['cmd.exe', '/d', '/c', str(script)], capture_output=True)
(work / 'round90-baseline-link.log').write_bytes(result.stdout + result.stderr)
assert result.returncode == 0, result.stdout + result.stderr
script.unlink()
for name in ['seat_protect_cpp.exe', 'highs.dll', 'gurobi130.dll']:
    shutil.copy2(baseline / name, destination / name)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
record = dict(purpose='Controlled regression baseline: new replay parser linked with accepted restricted-master object; all other objects from candidate build.',
    accepted_algorithm_commit='6292a85d658f5c24d93057844a4b8d4f77345d8c',
    objects=[dict(path=str(p), sha256=sha(p)) for p in objects],
    executable=dict(path=str(executable), sha256=sha(executable)),
    original_baseline_executable_sha256=sha(baseline / 'seat_protect_cpp.exe'))
(work / 'round90-baseline-link.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print('Controlled baseline probe linked; accepted executables unchanged.')
