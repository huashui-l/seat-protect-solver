#include "native_group_constructor.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <numeric>
#include <tuple>

namespace full_cpp {

RichRemainingDiagnostics assign_rich_remaining(
    const Problem& problem, AssignmentState& state, const RichCandidateCache& cache,
    const std::vector<int>& group_indices,
    std::chrono::steady_clock::time_point global_deadline
) {
    using Clock = std::chrono::steady_clock;
    const auto deadline = std::min(global_deadline, Clock::now()
        + std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(
            std::max(0.0, problem.rich.stage3_time_budget))));
    RichRemainingDiagnostics diagnostics;
    const auto needs_care = [&](int p) {
        const auto& passenger = problem.passengers[p];
        const auto rule = problem.ssr_rules.find(passenger.ssr);
        return passenger.need_cared || (rule != problem.ssr_rules.end() && rule->second.requires_caregiver);
    };
    const auto priority = [&](int g) {
        int assigned = 0, minimum = 1000000000, protection = 0, care = 0;
        for (int p : problem.groups[g].passengers) {
            assigned += state.passenger_to_seat[p] >= 0;
            care += needs_care(p);
            if (needs_care(p) || state.passenger_to_seat[p] >= 0) continue;
            int domain = 0;
            for (int seat : cache.rankings[p]) domain += state.rich_seat_feasible(p, seat);
            minimum = std::min(minimum, domain);
            protection += problem.passengers[p].need_both_empty ? 2 : problem.passengers[p].need_single_empty ? 1 : 0;
        }
        return std::make_tuple(assigned > 0 ? 0 : 1, minimum, -protection, -care,
            -static_cast<int>(problem.groups[g].passengers.size()));
    };
    auto groups = group_indices;
    std::stable_sort(groups.begin(), groups.end(), [&](int left, int right) { return priority(left) < priority(right); });
    const auto old_position = [&](int p) {
        const auto found = problem.seat_index.find(problem.passengers[p].old_seat);
        if (found == problem.seat_index.end()) return std::make_pair(999, 999);
        const auto& seat = problem.seats[found->second];
        int column = 0;
        for (char c : seat.column) column = column * 26 + (c - 'A' + 1);
        return std::make_pair(seat.row, column);
    };
    struct Move { int passenger, seat, block; };
    struct Branch {
        AssignmentSnapshot snapshot;
        std::vector<Move> moves;
        double cost = 0.0, compactness = 0.0;
    };
    for (int g : groups) {
        const auto& group = problem.groups[g];
        std::vector<int> remaining, anchors;
        for (int p : group.passengers) {
            if (state.passenger_to_seat[p] >= 0) anchors.push_back(state.passenger_to_seat[p]);
            else if (!needs_care(p)) remaining.push_back(p);
        }
        if (remaining.empty()) continue;
        ++diagnostics.groups_considered;
        std::stable_sort(remaining.begin(), remaining.end(), [&](int left, int right) {
            const auto& l = problem.passengers[left];
            const auto& r = problem.passengers[right];
            return std::make_tuple(!l.need_both_empty, !l.need_single_empty, old_position(left))
                < std::make_tuple(!r.need_both_empty, !r.need_single_empty, old_position(right));
        });
        const auto costs = build_rich_candidate_cache(problem, state, &cache.owner_regrets, g);
        const int cap = problem.rich.candidate_cap;
        const int retry_cap = std::max(cap, problem.rich.candidate_cap_retry);
        const int full_cap = std::max(retry_cap, problem.rich.candidate_cap_full_retry);
        std::vector<std::vector<int>> candidates(problem.passengers.size());
        // Python slicing retains all but the final |cap| elements for negative caps.
        const auto slice_size = [](size_t size, int limit) {
            return limit >= 0 ? std::min(size, static_cast<size_t>(limit))
                : static_cast<size_t>(std::max(0LL, static_cast<long long>(size) + limit));
        };
        for (int p : remaining) {
            for (int seat : costs.rankings[p])
                if (state.rich_seat_feasible(p, seat)) candidates[p].push_back(seat);
            candidates[p].resize(full_cap <= 0 ? 0 : std::min(candidates[p].size(), static_cast<size_t>(full_cap)));
        }
        const auto regret = [&](int p) {
            return slice_size(candidates[p].size(), cap) >= 2
                ? costs.costs[p][candidates[p][1]] - costs.costs[p][candidates[p][0]]
                : std::numeric_limits<double>::infinity();
        };
        std::stable_sort(remaining.begin(), remaining.end(), [&](int left, int right) {
            const auto& l = problem.passengers[left];
            const auto& r = problem.passengers[right];
            return std::make_tuple(!l.need_both_empty, !l.need_single_empty,
                       slice_size(candidates[left].size(), cap), -regret(left), old_position(left))
                < std::make_tuple(!r.need_both_empty, !r.need_single_empty,
                       slice_size(candidates[right].size(), cap), -regret(right), old_position(right));
        });
        const auto compactness = [&](const std::vector<Move>& moves, int extra = -1) {
            auto seats = anchors;
            for (const auto& move : moves) seats.push_back(move.seat);
            if (extra >= 0) seats.push_back(extra);
            if (seats.size() <= 1) return 0.0;
            double x = 0.0, y = 0.0;
            for (int seat : seats) { x += problem.seats[seat].x; y += problem.seats[seat].y; }
            x /= seats.size(); y /= seats.size();
            double dx = 0.0, dy = 0.0;
            for (int seat : seats) {
                dx = std::max(dx, std::abs(problem.seats[seat].x - x));
                dy = std::max(dy, std::abs(problem.seats[seat].y - y));
            }
            return problem.group_centroid_x_factor * dx + problem.group_centroid_y_factor * dy;
        };
        const auto commit = [&](const std::vector<Move>& moves) {
            const auto before = state.save();
            for (const auto& move : moves) {
                if (!state.assign(move.passenger, move.seat, move.block)) {
                    state.restore(before);
                    ++diagnostics.transaction_failures;
                    return false;
                }
            }
            return true;
        };
        AssignmentState local(problem);
        local.restore(state.save());
        // Static candidate filtering already checked global SSR constraints.
        // Python's branch check tracks only newly selected SSRs; commit checks
        // the combined global state transactionally.
        std::fill(local.seat_ssr_passenger.begin(), local.seat_ssr_passenger.end(), -1);
        const Branch initial{local.save(), {}, 0.0, compactness({})};
        const auto blocks = [&](int p, int seat) {
            std::vector<int> result;
            if (!local.can_assign(p, seat)) return result;
            if (problem.passengers[p].need_single_empty && !problem.passengers[p].need_both_empty) {
                for (int neighbor : problem.seats[seat].same_block_neighbors)
                    if (local.can_assign(p, seat, neighbor)) result.push_back(neighbor);
            } else result.push_back(-1);
            return result;
        };
        const auto care_satisfied = [&]() {
            for (int p : group.passengers) {
                const int seat = local.passenger_to_seat[p];
                if (seat < 0 || !needs_care(p)) continue;
                const auto rule = problem.ssr_rules.find(problem.passengers[p].ssr);
                const bool cross = rule != problem.ssr_rules.end() && rule->second.caregiver_allow_cross_aisle;
                const auto& neighbors = cross ? problem.seats[seat].row_neighbors : problem.seats[seat].same_block_neighbors;
                bool found = false;
                for (int other : group.passengers) {
                    const auto& passenger = problem.passengers[other];
                    if (passenger.ssr.empty() && !passenger.need_cared && !passenger.need_both_empty && !passenger.need_single_empty
                        && std::find(neighbors.begin(), neighbors.end(), local.passenger_to_seat[other]) != neighbors.end()) found = true;
                }
                if (!found) return false;
            }
            return true;
        };
        std::vector<Move> best, selected;
        double best_cost = std::numeric_limits<double>::infinity();
        if (problem.rich.small_group_dfs_enabled && remaining.size() <= static_cast<size_t>(std::max(1, problem.rich.small_group_dfs_max_size))
            && problem.rich.small_group_dfs_time_limit > 0.0 && Clock::now() < deadline) {
            ++diagnostics.dfs_attempted;
            const auto dfs_deadline = std::min(deadline, Clock::now()
                + std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(problem.rich.small_group_dfs_time_limit)));
            long long nodes = 0;
            const long long limit = std::max(1LL, problem.rich.small_group_dfs_node_limit);
            const bool bound_search = problem.rich_stage_budgets.business_time_limit <= 5.0
                && problem.weight_c <= 0.0 && problem.group_centroid_x_factor >= 0.0
                && problem.group_centroid_y_factor >= 0.0;
            std::vector<double> suffix_min(remaining.size() + 1, 0.0);
            if (bound_search) for (size_t depth = remaining.size(); depth-- > 0;) {
                const int p = remaining[depth];
                double minimum = std::numeric_limits<double>::infinity();
                for (int seat : candidates[p]) minimum = std::min(minimum, costs.costs[p][seat]);
                suffix_min[depth] = suffix_min[depth + 1] + minimum;
            }
            const auto dfs = [&](auto&& self, size_t depth, double cost, int active_cap) -> void {
                ++nodes;
                if (nodes > limit || Clock::now() >= dfs_deadline) return;
                if (bound_search && !best.empty()) {
                    double x_low = std::numeric_limits<double>::infinity(), x_high = -x_low;
                    double y_low = x_low, y_high = -x_low;
                    const auto include = [&](int seat) {
                        x_low = std::min(x_low, problem.seats[seat].x); x_high = std::max(x_high, problem.seats[seat].x);
                        y_low = std::min(y_low, problem.seats[seat].y); y_high = std::max(y_high, problem.seats[seat].y);
                    };
                    for (int seat : anchors) include(seat);
                    for (const auto& move : selected) include(move.seat);
                    // Any final centroid has maximum distance at least half
                    // the span of seats that have already been selected.
                    const double span = x_low <= x_high ? 0.5 * (
                        problem.group_centroid_x_factor * (x_high - x_low)
                        + problem.group_centroid_y_factor * (y_high - y_low)) : 0.0;
                    if (cost + suffix_min[depth] - problem.weight_c * span > best_cost + 1e-10) return;
                }
                if (depth == remaining.size()) {
                    if (!care_satisfied()) return;
                    const double total = cost - problem.weight_c * compactness(selected);
                    if (total < best_cost) { best_cost = total; best = selected; }
                    return;
                }
                const int p = remaining[depth];
                const auto before = local.save();
                for (size_t i = 0; i < slice_size(candidates[p].size(), active_cap); ++i) {
                    const int seat = candidates[p][i];
                    if (bound_search && cost + costs.costs[p][seat] + suffix_min[depth + 1] > best_cost + 1e-10) continue;
                    for (int block : blocks(p, seat)) {
                        if (!local.assign(p, seat, block)) continue;
                        selected.push_back({p, seat, block});
                        self(self, depth + 1, cost + costs.costs[p][seat], active_cap);
                        selected.pop_back();
                        local.restore(before);
                        if (bound_search && (nodes > limit || Clock::now() >= dfs_deadline)) return;
                    }
                }
            };
            std::vector<int> caps;
            for (int value : {cap, retry_cap, full_cap})
                if (std::find(caps.begin(), caps.end(), value) == caps.end()) caps.push_back(value);
            for (int active_cap : caps) {
                dfs(dfs, 0, 0.0, active_cap);
                if (!best.empty() || nodes > limit || Clock::now() >= dfs_deadline) break;
            }
            diagnostics.dfs_nodes += nodes;
        }
        if (!best.empty() && commit(best)) { ++diagnostics.dfs_succeeded; continue; }
        ++diagnostics.beam_groups;
        const int width = std::max(1, remaining.size() <= 2 ? problem.rich.beam_width_small
            : remaining.size() <= 5 ? problem.rich.beam_width_medium : problem.rich.beam_width_large);
        const int moves_limit = std::max(1, remaining.size() <= 2 ? problem.rich.beam_moves_small
            : remaining.size() <= 5 ? problem.rich.beam_moves_medium : problem.rich.beam_moves_large);
        const auto objective = [&](const Branch& branch) {
            return std::make_pair(remaining.size() - branch.moves.size(), branch.cost - problem.weight_c * branch.compactness);
        };
        std::vector<Branch> beam{initial};
        for (int p : remaining) {
            if (Clock::now() >= deadline) break;
            std::vector<Branch> expanded;
            for (const auto& branch : beam) {
                expanded.push_back(branch);
                local.restore(branch.snapshot);
                std::vector<std::pair<double, int>> moves;
                for (size_t i = 0; i < slice_size(candidates[p].size(), cap); ++i) {
                    const int seat = candidates[p][i];
                    if (blocks(p, seat).empty()) continue;
                    moves.emplace_back(costs.costs[p][seat] - problem.weight_c * (compactness(branch.moves, seat) - branch.compactness), seat);
                }
                std::stable_sort(moves.begin(), moves.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
                if (moves.size() > static_cast<size_t>(moves_limit)) moves.resize(moves_limit);
                for (const auto& move : moves) {
                    for (int block : blocks(p, move.second)) {
                        local.assign(p, move.second, block);
                        Branch next{local.save(), branch.moves, branch.cost + costs.costs[p][move.second], 0.0};
                        next.moves.push_back({p, move.second, block});
                        next.compactness = compactness(next.moves);
                        expanded.push_back(std::move(next));
                        local.restore(branch.snapshot);
                    }
                }
            }
            using Key = std::tuple<std::vector<int>, std::vector<int>, std::vector<std::tuple<std::string, std::string, bool, bool>>>;
            std::map<Key, size_t> positions;
            std::vector<Branch> unique;
            for (auto& branch : expanded) {
                std::vector<int> occupied, blocked;
                std::vector<std::tuple<std::string, std::string, bool, bool>> ssrs;
                for (int seat = 0; seat < static_cast<int>(problem.seats.size()); ++seat) {
                    if (branch.snapshot.seat_to_passenger[seat] >= 0) occupied.push_back(seat);
                    if (branch.snapshot.blocked_count[seat] > 0) blocked.push_back(seat);
                    const int p_ssr = branch.snapshot.seat_ssr_passenger[seat];
                    if (p_ssr >= 0) {
                        const auto& passenger = problem.passengers[p_ssr];
                        ssrs.emplace_back(problem.seats[seat].id, passenger.ssr, passenger.same_subrow_no_other_ssr, passenger.same_row_no_other_ssr);
                    }
                }
                std::sort(ssrs.begin(), ssrs.end());
                const Key key{occupied, blocked, ssrs};
                const auto inserted = positions.emplace(key, unique.size());
                if (inserted.second) unique.push_back(std::move(branch));
                else if (objective(branch) < objective(unique[inserted.first->second])) unique[inserted.first->second] = std::move(branch);
            }
            std::stable_sort(unique.begin(), unique.end(), [&](const Branch& a, const Branch& b) { return objective(a) < objective(b); });
            if (unique.size() > static_cast<size_t>(width)) unique.resize(width);
            beam = std::move(unique);
            if (beam.empty()) beam.push_back(initial);
        }
        std::stable_sort(beam.begin(), beam.end(), [&](const Branch& a, const Branch& b) { return objective(a) < objective(b); });
        for (const auto& branch : beam) if (commit(branch.moves)) break;
    }
    return diagnostics;
}

int assign_rich_paired_ssrs(
    const Problem& problem, AssignmentState& state, const RichCandidateCache& cache,
    std::chrono::steady_clock::time_point deadline
) {
    const int before = static_cast<int>(std::count_if(state.passenger_to_seat.begin(), state.passenger_to_seat.end(),
        [](int seat) { return seat >= 0; }));
    const auto needs_care = [&](int p) {
        const auto& passenger = problem.passengers[p];
        const auto rule = problem.ssr_rules.find(passenger.ssr);
        return passenger.need_cared || (rule != problem.ssr_rules.end() && rule->second.requires_caregiver);
    };
    const auto adult = [&](int p) {
        const auto& passenger = problem.passengers[p];
        return passenger.ssr.empty() && !passenger.need_cared && !passenger.need_both_empty && !passenger.need_single_empty;
    };
    const auto neighbors = [&](int p, int seat) -> const std::vector<int>& {
        const auto rule = problem.ssr_rules.find(problem.passengers[p].ssr);
        const bool cross = rule != problem.ssr_rules.end() && rule->second.caregiver_allow_cross_aisle;
        return cross ? problem.seats[seat].row_neighbors : problem.seats[seat].same_block_neighbors;
    };
    const auto compactness = [&](const std::vector<int>& seats) {
        if (seats.size() <= 1) return 0.0;
        double x = 0.0, y = 0.0;
        for (int seat : seats) { x += problem.seats[seat].x; y += problem.seats[seat].y; }
        x /= seats.size(); y /= seats.size();
        double dx = 0.0, dy = 0.0;
        for (int seat : seats) {
            dx = std::max(dx, std::abs(problem.seats[seat].x - x));
            dy = std::max(dy, std::abs(problem.seats[seat].y - y));
        }
        return problem.group_centroid_x_factor * dx + problem.group_centroid_y_factor * dy;
    };
    std::vector<int> groups(problem.groups.size());
    std::iota(groups.begin(), groups.end(), 0);
    const auto priority = [&](int g) {
        bool baby = false;
        int care = 0;
        for (int p : problem.groups[g].passengers) {
            care += needs_care(p);
            baby = baby || (needs_care(p) && problem.passengers[p].ssr == "BSCT");
        }
        return std::make_tuple(baby ? 0 : 1, -care, problem.groups[g].id);
    };
    std::stable_sort(groups.begin(), groups.end(), [&](int a, int b) { return priority(a) < priority(b); });
    for (int g : groups) {
        if (std::chrono::steady_clock::now() >= deadline) break;
        std::vector<int> caregivers;
        for (int p : problem.groups[g].passengers) if (adult(p)) caregivers.push_back(p);
        for (int p : problem.groups[g].passengers) {
            if (!needs_care(p)) continue;
            if (std::chrono::steady_clock::now() >= deadline) break;
            auto costs = build_rich_candidate_cache(problem, state, &cache.owner_regrets, g);
            if (state.passenger_to_seat[p] >= 0) {
                const int seat = state.passenger_to_seat[p];
                const auto& adjacent = neighbors(p, seat);
                bool satisfied = false;
                for (int cg : caregivers) {
                    if (std::find(adjacent.begin(), adjacent.end(), state.passenger_to_seat[cg]) != adjacent.end()) satisfied = true;
                }
                if (satisfied) continue;
                int best_caregiver = -1, best_seat = -1;
                double best_cost = std::numeric_limits<double>::infinity();
                for (int cg : caregivers) {
                    if (state.passenger_to_seat[cg] >= 0) continue;
                    for (int neighbor : adjacent) {
                        if (state.rich_seat_feasible(cg, neighbor, -1, seat) && costs.costs[cg][neighbor] < best_cost) {
                            best_cost = costs.costs[cg][neighbor]; best_caregiver = cg; best_seat = neighbor;
                        }
                    }
                }
                if (best_caregiver >= 0) {
                    state.assign(best_caregiver, best_seat, -1, seat);
                    continue;
                }
                if (!problem.passengers[p].fixed_seat.empty()) continue;
                state.remove(p);
                costs = build_rich_candidate_cache(problem, state, &cache.owner_regrets, g);
            }
            std::vector<int> assigned;
            for (int other : problem.groups[g].passengers)
                if (state.passenger_to_seat[other] >= 0) assigned.push_back(state.passenger_to_seat[other]);
            const double old_compactness = compactness(assigned);
            int best_seat = -1, best_caregiver_seat = -1;
            double best_cost = std::numeric_limits<double>::infinity();
            for (int cg : caregivers) {
                const int caregiver_seat = state.passenger_to_seat[cg];
                if (caregiver_seat < 0) continue;
                for (int neighbor : neighbors(p, caregiver_seat)) {
                    if (!state.rich_seat_feasible(p, neighbor, -1, caregiver_seat)) continue;
                    auto expanded = assigned;
                    expanded.push_back(neighbor);
                    const double cost = costs.costs[p][neighbor] - problem.weight_c * (compactness(expanded) - old_compactness);
                    if (cost < best_cost) { best_cost = cost; best_seat = neighbor; best_caregiver_seat = caregiver_seat; }
                }
            }
            if (best_seat >= 0 && state.assign(p, best_seat, -1, best_caregiver_seat)) continue;
            std::vector<int> unassigned;
            for (int cg : caregivers) if (state.passenger_to_seat[cg] < 0) unassigned.push_back(cg);
            if (unassigned.empty()) continue;
            struct Pair { double cost; int seat, caregiver_seat, caregiver; };
            std::vector<Pair> pairs;
            int feasible_count = 0;
            for (int seat : cache.rankings[p]) {
                if (std::chrono::steady_clock::now() >= deadline) break;
                if (!state.rich_seat_feasible(p, seat)) continue;
                ++feasible_count;
                for (int neighbor : neighbors(p, seat)) {
                    for (int cg : unassigned) {
                        if (!state.rich_seat_feasible(cg, neighbor, -1, seat)) continue;
                        double penalty = 0.0;
                        if (!assigned.empty()) {
                            auto expanded = assigned;
                            expanded.push_back(seat); expanded.push_back(neighbor);
                            penalty = -problem.weight_c * (compactness(expanded) - old_compactness);
                        }
                        pairs.push_back({costs.costs[p][seat] + costs.costs[cg][neighbor] + penalty, seat, neighbor, cg});
                    }
                }
                if (feasible_count >= 500) break;
            }
            std::stable_sort(pairs.begin(), pairs.end(), [](const Pair& a, const Pair& b) { return a.cost < b.cost; });
            for (const auto& pair : pairs) {
                if (state.passenger_to_seat[pair.caregiver] >= 0) continue;
                if (state.assign(pair.caregiver, pair.caregiver_seat, -1, pair.seat)) {
                    if (state.assign(p, pair.seat, -1, pair.caregiver_seat)) break;
                    state.remove(pair.caregiver);
                }
            }
        }
    }
    const int after = static_cast<int>(std::count_if(state.passenger_to_seat.begin(), state.passenger_to_seat.end(),
        [](int seat) { return seat >= 0; }));
    return std::max(0, after - before);
}

RichPairedRescueDiagnostics rescue_rich_paired_ssrs(
    const Problem& problem, AssignmentState& state, const RichCandidateCache& cache,
    std::chrono::steady_clock::time_point deadline
) {
    RichPairedRescueDiagnostics diagnostics;
    const auto expired = [&]() { return std::chrono::steady_clock::now() >= deadline; };
    const auto needs_care = [&](int p) {
        const auto& passenger = problem.passengers[p];
        const auto rule = problem.ssr_rules.find(passenger.ssr);
        return passenger.need_cared || (rule != problem.ssr_rules.end() && rule->second.requires_caregiver);
    };
    const auto adult = [&](int p) {
        const auto& passenger = problem.passengers[p];
        return passenger.ssr.empty() && !passenger.need_cared && !passenger.need_both_empty && !passenger.need_single_empty;
    };
    const auto neighbors = [&](int p, int seat) -> const std::vector<int>& {
        const auto rule = problem.ssr_rules.find(problem.passengers[p].ssr);
        const bool cross = rule != problem.ssr_rules.end() && rule->second.caregiver_allow_cross_aisle;
        return cross ? problem.seats[seat].row_neighbors : problem.seats[seat].same_block_neighbors;
    };
    const auto satisfied = [&](int p) {
        const int seat = state.passenger_to_seat[p];
        if (seat < 0) return false;
        const auto& adjacent = neighbors(p, seat);
        for (int cg : problem.groups[problem.passengers[p].group].passengers)
            if (cg != p && adult(cg)
                && std::find(adjacent.begin(), adjacent.end(), state.passenger_to_seat[cg]) != adjacent.end()) return true;
        return false;
    };
    using Placement = std::pair<int, int>;
    const auto rebuild = [&](const Group& group) {
        std::vector<Placement> original;
        for (int p : group.passengers) {
            if (state.passenger_to_seat[p] >= 0) {
                original.emplace_back(p, state.passenger_to_seat[p]);
                state.remove(p);
            }
        }
        const int cap = std::max(24, problem.rich.paired_joint_rebuild_candidate_cap);
        const long long limit = std::max(1LL, problem.rich.paired_joint_rebuild_node_limit);
        std::vector<std::vector<int>> candidates(problem.passengers.size());
        std::vector<int> caregivers;
        for (int p : group.passengers) {
            const auto& fixed = problem.passengers[p].fixed_seat;
            if (!fixed.empty()) {
                const auto seat = problem.seat_index.find(fixed);
                if (seat != problem.seat_index.end()) candidates[p].push_back(seat->second);
            } else {
                candidates[p] = cache.rankings[p];
                if (candidates[p].size() > static_cast<size_t>(cap)) candidates[p].resize(cap);
            }
            if (adult(p)) caregivers.push_back(p);
        }
        std::vector<Placement> selected, solution;
        bool found = false;
        long long nodes = 0;
        const auto partial_care_feasible = [&](int p, int seat) {
            if (caregivers.size() != 1) return true;
            const int cg = caregivers.front();
            if (p == cg) {
                for (const auto& placement : selected) {
                    if (!needs_care(placement.first)) continue;
                    const auto& adjacent = neighbors(placement.first, placement.second);
                    if (std::find(adjacent.begin(), adjacent.end(), seat) == adjacent.end()) return false;
                }
            } else if (needs_care(p) && state.passenger_to_seat[cg] >= 0) {
                const auto& adjacent = neighbors(p, seat);
                if (std::find(adjacent.begin(), adjacent.end(), state.passenger_to_seat[cg]) == adjacent.end()) return false;
            }
            return true;
        };
        const auto search = [&](auto&& self, const std::vector<int>& remaining) -> void {
            if (found) return;
            if (++nodes > limit || expired()) return;
            if (remaining.empty()) {
                for (int p : group.passengers) if (needs_care(p) && !satisfied(p)) return;
                solution = selected; found = true; return;
            }
            int best = -1;
            std::vector<int> feasible;
            for (int p : remaining) {
                std::vector<int> options;
                for (int seat : candidates[p])
                    if (state.rich_seat_feasible(p, seat) && partial_care_feasible(p, seat)) options.push_back(seat);
                if (best < 0 || std::make_tuple(options.size(), !needs_care(p), problem.passengers[p].hostnum)
                    < std::make_tuple(feasible.size(), !needs_care(best), problem.passengers[best].hostnum)) {
                    best = p; feasible = std::move(options);
                }
            }
            if (feasible.empty()) return;
            auto next = remaining;
            next.erase(std::find(next.begin(), next.end(), best));
            for (int seat : feasible) {
                if (state.assign(best, seat)) {
                    selected.emplace_back(best, seat);
                    self(self, next);
                    state.remove(best); selected.pop_back();
                    if (found) return;
                }
            }
        };
        search(search, group.passengers);
        const auto restore = [&](std::vector<Placement> placements) {
            std::stable_sort(placements.begin(), placements.end(), [&](const Placement& a, const Placement& b) {
                return needs_care(a.first) < needs_care(b.first);
            });
            bool restored = true;
            for (const auto& placement : placements)
                restored = state.assign(placement.first, placement.second) && restored;
            return restored;
        };
        if (!found) { restore(original); return false; }
        if (restore(solution)) return true;
        for (const auto& placement : solution)
            if (state.passenger_to_seat[placement.first] >= 0) state.remove(placement.first);
        restore(original);
        return false;
    };
    struct Option { double cost; int caregiver, seat, caregiver_seat; };
    struct TaskPlacement { int passenger, caregiver, seat, caregiver_seat; };
    for (const auto& group : problem.groups) {
        if (expired()) break;
        std::vector<int> fixed_unsatisfied;
        for (int p : group.passengers)
            if (needs_care(p) && !problem.passengers[p].fixed_seat.empty()
                && state.passenger_to_seat[p] >= 0 && !satisfied(p)) fixed_unsatisfied.push_back(p);
        for (int p : fixed_unsatisfied) {
            diagnostics.attempted.push_back(p);
            const int seat = state.passenger_to_seat[p];
            const auto costs = build_rich_candidate_cache(problem, state, &cache.owner_regrets, problem.passengers[p].group);
            struct Candidate { double cost; int caregiver, seat, old_seat, displaced, new_seat; };
            std::vector<Candidate> candidates;
            for (int cg : group.passengers) {
                if (!adult(cg)) continue;
                const int old = state.passenger_to_seat[cg];
                if (!problem.passengers[cg].fixed_seat.empty() && old >= 0) continue;
                for (int cg_seat : neighbors(p, seat)) {
                    const int displaced = state.seat_to_passenger[cg_seat];
                    int new_seat = -1;
                    if (displaced >= 0 && cg_seat != old) {
                        if (!problem.passengers[displaced].fixed_seat.empty() || !adult(displaced)) continue;
                        for (int candidate : cache.rankings[displaced]) {
                            if (candidate != cg_seat && state.rich_seat_feasible(displaced, candidate)) { new_seat = candidate; break; }
                        }
                        if (new_seat < 0) continue;
                    }
                    candidates.push_back({costs.costs[cg][cg_seat], cg, cg_seat, old, displaced, new_seat});
                }
            }
            std::stable_sort(candidates.begin(), candidates.end(), [](const Candidate& a, const Candidate& b) { return a.cost < b.cost; });
            bool rescued = false;
            for (const auto& candidate : candidates) {
                if (expired()) break;
                const auto before = state.save();
                if (candidate.old_seat >= 0) state.remove(candidate.caregiver);
                if (candidate.displaced >= 0) state.remove(candidate.displaced);
                const bool caregiver_ok = state.assign(candidate.caregiver, candidate.seat, -1, seat);
                const bool displaced_ok = candidate.displaced < 0
                    || (caregiver_ok && state.assign(candidate.displaced, candidate.new_seat));
                if (caregiver_ok && displaced_ok) { rescued = true; diagnostics.rescued.push_back(p); break; }
                state.restore(before);
            }
            if (!rescued) diagnostics.unresolved.push_back(p);
        }
        std::vector<int> tasks;
        for (int p : group.passengers) if (needs_care(p) && state.passenger_to_seat[p] < 0) tasks.push_back(p);
        if (tasks.empty()) continue;
        diagnostics.attempted.insert(diagnostics.attempted.end(), tasks.begin(), tasks.end());
        std::vector<TaskPlacement> plan, best;
        double best_cost = std::numeric_limits<double>::infinity();
        int nodes = 0;
        const int option_cap = problem.rich.paired_rescue_option_cap;
        const auto options_for = [&](int p) {
            std::vector<Option> options;
            const auto costs = build_rich_candidate_cache(problem, state, &cache.owner_regrets, problem.passengers[p].group);
            for (int cg : group.passengers) {
                if (!adult(cg)) continue;
                if (expired()) break;
                const int cg_seat = state.passenger_to_seat[cg];
                if (cg_seat >= 0) {
                    for (int seat : neighbors(p, cg_seat))
                        if (state.rich_seat_feasible(p, seat, -1, cg_seat)) options.push_back({costs.costs[p][seat], cg, seat, -1});
                    continue;
                }
                for (int seat : cache.rankings[p]) {
                    if (expired()) break;
                    if (!state.rich_seat_feasible(p, seat)) continue;
                    for (int neighbor : neighbors(p, seat))
                        if (state.rich_seat_feasible(cg, neighbor, -1, seat))
                            options.push_back({costs.costs[p][seat] + costs.costs[cg][neighbor], cg, seat, neighbor});
                    if (static_cast<int>(options.size()) >= option_cap * 3) break;
                }
            }
            std::stable_sort(options.begin(), options.end(), [](const Option& a, const Option& b) { return a.cost < b.cost; });
            if (option_cap <= 0) options.clear();
            else if (options.size() > static_cast<size_t>(option_cap)) options.resize(option_cap);
            return options;
        };
        const auto search = [&](auto&& self, size_t index, double cost) -> void {
            if (++nodes > 1000 || expired()) return;
            if (index == tasks.size()) {
                if (plan.size() > best.size() || (plan.size() == best.size() && cost < best_cost)) {
                    best = plan; best_cost = cost;
                }
                return;
            }
            const int p = tasks[index];
            self(self, index + 1, cost);
            for (const auto& option : options_for(p)) {
                if (option.caregiver_seat >= 0 && !state.assign(option.caregiver, option.caregiver_seat, -1, option.seat)) continue;
                const int cg_seat = option.caregiver_seat >= 0 ? option.caregiver_seat : state.passenger_to_seat[option.caregiver];
                if (state.assign(p, option.seat, -1, cg_seat)) {
                    plan.push_back({p, option.caregiver, option.seat, option.caregiver_seat});
                    self(self, index + 1, cost + option.cost);
                    plan.pop_back(); state.remove(p);
                }
                if (option.caregiver_seat >= 0) state.remove(option.caregiver);
            }
        };
        search(search, 0, 0.0);
        for (const auto& placement : best) {
            if (placement.caregiver_seat >= 0) state.assign(placement.caregiver, placement.caregiver_seat, -1, placement.seat);
            const int cg_seat = state.passenger_to_seat[placement.caregiver];
            state.assign(placement.passenger, placement.seat, -1, cg_seat);
            diagnostics.rescued.push_back(placement.passenger);
        }
        std::vector<int> remaining;
        for (int p : tasks) if (state.passenger_to_seat[p] < 0) remaining.push_back(p);
        if (!remaining.empty() && rebuild(group)) {
            ++diagnostics.joint_rebuilds;
            diagnostics.rescued.insert(diagnostics.rescued.end(), remaining.begin(), remaining.end());
        }
        for (int p : tasks) if (state.passenger_to_seat[p] < 0) diagnostics.unresolved.push_back(p);
        for (int p : fixed_unsatisfied)
            if (!satisfied(p) && std::find(diagnostics.unresolved.begin(), diagnostics.unresolved.end(), p) == diagnostics.unresolved.end())
                diagnostics.unresolved.push_back(p);
    }
    return diagnostics;
}

RichConstructionDiagnostics construct_rich_assignment(
    const Problem& problem, AssignmentState& state, const RichCandidateCache& cache,
    std::chrono::steady_clock::time_point construction_deadline
) {
    RichConstructionDiagnostics diagnostics;
    std::vector<int> anchored, groups;
    for (int g = 0; g < static_cast<int>(problem.groups.size()); ++g) {
        groups.push_back(g);
        if (std::any_of(problem.groups[g].passengers.begin(), problem.groups[g].passengers.end(),
                [&](int p) { return state.passenger_to_seat[p] >= 0; })) anchored.push_back(g);
    }
    const auto capture = [&](const RichRemainingDiagnostics& update) {
        diagnostics.search.groups_considered += update.groups_considered;
        diagnostics.search.transaction_failures += update.transaction_failures;
        diagnostics.search.dfs_attempted += update.dfs_attempted;
        diagnostics.search.dfs_succeeded += update.dfs_succeeded;
        diagnostics.search.dfs_nodes += update.dfs_nodes;
        diagnostics.search.beam_groups += update.beam_groups;
    };
    if (!anchored.empty()) capture(assign_rich_remaining(problem, state, cache, anchored, construction_deadline));
    while (diagnostics.paired_passes < 4 && std::chrono::steady_clock::now() < construction_deadline) {
        const int added = assign_rich_paired_ssrs(problem, state, cache, construction_deadline);
        ++diagnostics.paired_passes;
        if (added <= 0) break;
    }
    diagnostics.rescue = rescue_rich_paired_ssrs(problem, state, cache, construction_deadline);
    capture(assign_rich_remaining(problem, state, cache, groups, construction_deadline));
    return diagnostics;
}

RichOrdinaryVndDiagnostics improve_rich_ordinary_vnd(
    AssignmentState& state, const std::vector<std::vector<int>>& rankings,
    std::chrono::steady_clock::time_point deadline, bool include_group_rebuild, bool include_caregiver_rebuild
) {
    RichOrdinaryVndDiagnostics diagnostics;
    const auto expired = [&]() { return std::chrono::steady_clock::now() >= deadline; };
    if (expired()) { diagnostics.stopped_by_deadline = true; return diagnostics; }
    const auto& problem = state.problem;
    const int n = static_cast<int>(problem.passengers.size());
    std::vector<bool> active(n, false), movable_set(n, false);
    for (const auto& group : problem.groups) for (int p : group.passengers) {
        const auto& passenger = problem.passengers[p];
        const auto rule = problem.ssr_rules.find(passenger.ssr);
        const int seat = state.passenger_to_seat[p];
        if (seat < 0 || (!passenger.need_cared &&
            (rule == problem.ssr_rules.end() || !rule->second.requires_caregiver))) continue;
        const bool cross = rule != problem.ssr_rules.end() && rule->second.caregiver_allow_cross_aisle;
        const auto& neighbors = cross ? problem.seats[seat].row_neighbors : problem.seats[seat].same_block_neighbors;
        for (int cg : group.passengers) {
            const auto& item = problem.passengers[cg];
            if (item.ssr.empty() && !item.need_both_empty && !item.need_single_empty
                && std::find(neighbors.begin(), neighbors.end(), state.passenger_to_seat[cg]) != neighbors.end()) active[cg] = true;
        }
    }
    std::vector<int> movable;
    for (int p = 0; p < n; ++p) {
        const auto& item = problem.passengers[p];
        if (state.passenger_to_seat[p] >= 0 && item.fixed_seat.empty() && item.ssr.empty()
            && !item.need_cared && !item.need_both_empty && !item.need_single_empty && !active[p]) {
            movable.push_back(p); movable_set[p] = true;
        }
    }
    if (movable.empty()) return diagnostics;
    // Infant positions stay fixed during ordinary moves; cache their pair costs.
    std::vector<int> infants;
    for (int p = 0; p < n; ++p)
        if (problem.passengers[p].ssr == "BSCT" && state.passenger_to_seat[p] >= 0) infants.push_back(p);
    const size_t seat_count = problem.seats.size();
    std::vector<double> passenger_cache(static_cast<size_t>(n) * seat_count,
        std::numeric_limits<double>::quiet_NaN());
    const auto passenger_score = [&](int p, int s) {
        double& cached = passenger_cache[static_cast<size_t>(p) * seat_count + s];
        if (!std::isnan(cached)) return cached;
        const auto& target = problem.seats[s];
        double baby = 0.0;
        for (int infant : infants) {
            if (problem.passengers[infant].group == problem.passengers[p].group) continue;
            const int infant_seat = state.passenger_to_seat[infant];
            const auto& seat = problem.seats[infant_seat];
            if (s == infant_seat || seat.cabin != target.cabin) continue;
            const double distance = 1.0 + std::abs(seat.x - target.x);
            if (seat.row == target.row && seat.subrow == target.subrow) baby += problem.weight_b / distance;
            else if (std::abs(seat.row - target.row) == 1)
                baby += problem.weight_b * problem.baby_front_back_factor / distance;
        }
        cached = evaluate_rich_individual_score(problem, p, s).total() + baby;
        return cached;
    };
    std::vector<std::vector<int>> group_seats(problem.groups.size());
    for (int p : state.assignment_order)
        group_seats[problem.passengers[p].group].push_back(state.passenger_to_seat[p]);
    const auto compact = [&](const std::vector<int>& seats) {
        if (seats.size() <= 1) return 0.0;
        double x = 0.0, y = 0.0, dx = 0.0, dy = 0.0;
        for (int s : seats) { x += problem.seats[s].x; y += problem.seats[s].y; }
        x /= seats.size(); y /= seats.size();
        for (int s : seats) { dx = std::max(dx, std::abs(problem.seats[s].x - x)); dy = std::max(dy, std::abs(problem.seats[s].y - y)); }
        return problem.weight_c * (problem.group_centroid_x_factor * dx + problem.group_centroid_y_factor * dy);
    };
    const auto attempt = [&](const std::vector<int>& passengers, const std::vector<int>& targets) {
        ++diagnostics.evaluated_moves;
        double delta = 0.0;
        std::map<int, std::map<int, int>> replacements;
        for (size_t i = 0; i < passengers.size(); ++i) {
            const int p = passengers[i], old = state.passenger_to_seat[p];
            delta += passenger_score(p, targets[i]) - passenger_score(p, old);
            replacements[problem.passengers[p].group][old] = targets[i];
        }
        std::map<int, std::vector<int>> updated;
        for (const auto& group : replacements) {
            auto seats = group_seats[group.first];
            for (int& seat : seats) {
                const auto replacement = group.second.find(seat);
                if (replacement != group.second.end()) seat = replacement->second;
            }
            if (passengers.size() == 2 && replacements.size() == 1) seats = group_seats[group.first];
            delta += compact(seats) - compact(group_seats[group.first]);
            updated[group.first] = std::move(seats);
        }
        if (delta <= problem.rich.local_search_epsilon) return false;
        const auto snapshot = state.save();
        for (int p : passengers) state.remove(p);
        for (size_t i = 0; i < passengers.size(); ++i) if (!state.assign(passengers[i], targets[i])) {
            state.restore(snapshot);
            for (int moved : passengers) state.remove(moved);
            for (int moved : passengers) state.assign(moved, snapshot.passenger_to_seat[moved]);
            return false;
        }
        for (auto& group : updated) group_seats[group.first] = std::move(group.second);
        ++diagnostics.accepted_moves;
        diagnostics.score_improvement += delta;
        return true;
    };
    const int cap = std::max(4, problem.rich.local_search_candidate_cap);
    while (!expired()) {
        ++diagnostics.passes;
        bool accepted = false;
        std::stable_sort(movable.begin(), movable.end(), [&](int left, int right) {
            return passenger_score(left, state.passenger_to_seat[left]) < passenger_score(right, state.passenger_to_seat[right]);
        });
        for (int p : movable) {
            if (expired()) break;
            const int old = state.passenger_to_seat[p];
            for (int i = 0; i < std::min(cap, static_cast<int>(rankings[p].size())); ++i) {
                if (expired()) break;
                const int seat = rankings[p][i], other = state.seat_to_passenger[seat];
                if (seat == old || state.blocked_count[seat] > 0 || (other >= 0 && !movable_set[other])) continue;
                accepted = other < 0 ? attempt({p}, {seat}) : attempt({p, other}, {seat, old});
                if (accepted) { if (other < 0) ++diagnostics.one_opt; else ++diagnostics.swaps; break; }
            }
            if (accepted) break;
        }
        if (!accepted) break;
    }
    const int cycle_cap = std::max(4, problem.rich.local_search_cycle_candidate_cap);
    while (!expired()) {
        bool accepted = false;
        for (int first : movable) {
            if (expired()) break;
            for (int i = 0; i < std::min(cycle_cap, static_cast<int>(rankings[first].size())); ++i) {
                const int second = state.seat_to_passenger[rankings[first][i]];
                if (second < 0 || second == first || !movable_set[second]) continue;
                for (int j = 0; j < std::min(cycle_cap, static_cast<int>(rankings[second].size())); ++j) {
                    if (expired()) break;
                    const int third = state.seat_to_passenger[rankings[second][j]];
                    if (third < 0 || third == first || third == second || !movable_set[third]) continue;
                    accepted = attempt({first, second, third}, {state.passenger_to_seat[second],
                        state.passenger_to_seat[third], state.passenger_to_seat[first]});
                    if (accepted) { ++diagnostics.cycles; break; }
                }
                if (accepted) break;
            }
            if (accepted) break;
        }
        if (!accepted) break;
    }
    if (!include_group_rebuild) return diagnostics;
    std::vector<std::vector<int>> keys_by_group(problem.groups.size());
    std::vector<int> group_order, rebuild_groups;
    for (int p : state.assignment_order) {
        const int g = problem.passengers[p].group;
        if (keys_by_group[g].empty()) group_order.push_back(g);
        keys_by_group[g].push_back(p);
    }
    for (int g : group_order)
        if (std::all_of(keys_by_group[g].begin(), keys_by_group[g].end(),
                [&](int p) { return movable_set[p]; })) rebuild_groups.push_back(g);
    const int partner_cap = std::max(2, problem.rich.local_search_related_group_cap);
    const int related_cap = std::max(cycle_cap, problem.rich.local_search_related_candidate_cap);
    const auto popcount = [](unsigned mask) {
        int count = 0;
        while (mask) { mask &= mask - 1; ++count; }
        return count;
    };
    const auto matching = [&](const std::vector<int>& keys, const std::vector<int>& seats) {
        const unsigned count = 1u << keys.size();
        std::vector<double> dp(count, -std::numeric_limits<double>::infinity());
        std::vector<int> parent(count, -1);
        dp[0] = 0.0;
        for (unsigned mask = 0; mask < count; ++mask) {
            const int index = popcount(mask);
            if (index >= static_cast<int>(keys.size()) || !std::isfinite(dp[mask])) continue;
            for (int j = 0; j < static_cast<int>(seats.size()); ++j) {
                if (mask & (1u << j)) continue;
                const unsigned next = mask | (1u << j);
                const double value = dp[mask] + passenger_score(keys[index], seats[j]);
                if (value > dp[next]) { dp[next] = value; parent[next] = j; }
            }
        }
        std::vector<std::pair<int, int>> placement;
        unsigned mask = count - 1;
        while (mask) {
            const int j = parent[mask];
            const unsigned previous = mask ^ (1u << j);
            placement.emplace_back(keys[popcount(previous)], seats[j]);
            mask = previous;
        }
        return std::make_pair(dp.back(), placement);
    };
    const auto center = [&](int g) {
        double sum = 0.0;
        for (int p : keys_by_group[g]) sum += problem.seats[state.passenger_to_seat[p]].row;
        return sum / keys_by_group[g].size();
    };
    while (!expired()) {
        bool accepted = false;
        std::stable_sort(rebuild_groups.begin(), rebuild_groups.end(), [&](int left, int right) {
            return compact(group_seats[left]) < compact(group_seats[right]);
        });
        for (int first : rebuild_groups) {
            if (expired()) break;
            std::vector<bool> preferred(problem.groups.size(), false);
            for (int p : keys_by_group[first])
                for (int i = 0; i < std::min(related_cap, static_cast<int>(rankings[p].size())); ++i) {
                    const int owner = state.seat_to_passenger[rankings[p][i]];
                    if (owner >= 0 && problem.passengers[owner].group != first) preferred[problem.passengers[owner].group] = true;
                }
            std::vector<int> partners;
            for (int g : rebuild_groups) if (g != first) partners.push_back(g);
            const double first_center = center(first);
            std::stable_sort(partners.begin(), partners.end(), [&](int left, int right) {
                return std::make_pair(!preferred[left], std::abs(first_center - center(left)))
                    < std::make_pair(!preferred[right], std::abs(first_center - center(right)));
            });
            if (partners.size() > static_cast<size_t>(partner_cap)) partners.resize(partner_cap);
            for (int second : partners) {
                auto keys = keys_by_group[first];
                keys.insert(keys.end(), keys_by_group[second].begin(), keys_by_group[second].end());
                if (keys.size() > 12) continue;
                std::vector<int> seats;
                double current = 0.0;
                for (int p : keys) { seats.push_back(state.passenger_to_seat[p]); current += passenger_score(p, seats.back()); }
                current += compact(group_seats[first]);
                current += compact(group_seats[second]);
                double best = current;
                std::vector<std::pair<int, int>> best_placement;
                for (unsigned mask = 1; mask < (1u << keys.size()) - 1; ++mask) {
                    if (expired()) break;
                    if (popcount(mask) != static_cast<int>(keys_by_group[first].size())) continue;
                    std::vector<int> left, right;
                    for (size_t i = 0; i < seats.size(); ++i) ((mask & (1u << i)) ? left : right).push_back(seats[i]);
                    const auto left_match = matching(keys_by_group[first], left);
                    const auto right_match = matching(keys_by_group[second], right);
                    const double value = left_match.first + right_match.first + compact(left) + compact(right);
                    ++diagnostics.evaluated_moves;
                    if (value > best + problem.rich.local_search_epsilon) {
                        best = value;
                        best_placement = left_match.second;
                        best_placement.insert(best_placement.end(), right_match.second.begin(), right_match.second.end());
                    }
                }
                if (best_placement.empty()) continue;
                const auto snapshot = state.save();
                for (int p : keys) state.remove(p);
                bool committed = true;
                for (const auto& item : best_placement) if (!state.assign(item.first, item.second)) { committed = false; break; }
                if (!committed) {
                    state.restore(snapshot);
                    for (int p : keys) state.remove(p);
                    for (int p : keys) state.assign(p, snapshot.passenger_to_seat[p]);
                    continue;
                }
                for (int g : {first, second}) {
                    group_seats[g].clear();
                    for (int p : keys_by_group[g]) group_seats[g].push_back(state.passenger_to_seat[p]);
                }
                ++diagnostics.accepted_moves;
                ++diagnostics.group_rebuilds;
                diagnostics.score_improvement += best - current;
                accepted = true;
                break;
            }
            if (accepted) break;
        }
        if (!accepted) break;
    }
    if (!include_caregiver_rebuild) return diagnostics;
    const auto requires_care = [&](int p) {
        const auto& item = problem.passengers[p];
        const auto rule = problem.ssr_rules.find(item.ssr);
        return item.need_cared || (rule != problem.ssr_rules.end() && rule->second.requires_caregiver);
    };
    const auto individual = [&](int p, int seat) {
        std::vector<int> isolated(n, -1);
        isolated[p] = seat;
        return evaluate_rich_group_score(problem, isolated, problem.passengers[p].group).total();
    };
    const auto baby_score = [&](const std::vector<int>& assignment) {
        return evaluate_score_components(problem, assignment).score_b;
    };
    double baseline_baby = baby_score(state.passenger_to_seat);
    for (int care_group : group_order) {
        const auto& care_keys = keys_by_group[care_group];
        if (!std::any_of(care_keys.begin(), care_keys.end(), requires_care)
            || !std::all_of(care_keys.begin(), care_keys.end(), [&](int p) {
                const auto& item = problem.passengers[p];
                return item.fixed_seat.empty() && !item.need_both_empty && !item.need_single_empty;
            })) continue;
        if (expired()) break;
        const double care_center = center(care_group);
        std::vector<bool> preferred(problem.groups.size(), false);
        for (int p : care_keys)
            for (int i = 0; i < std::min(related_cap, static_cast<int>(rankings[p].size())); ++i) {
                const int owner = state.seat_to_passenger[rankings[p][i]];
                if (owner >= 0 && problem.passengers[owner].group != care_group) preferred[problem.passengers[owner].group] = true;
            }
        std::vector<int> partners;
        for (int g : rebuild_groups) if (g != care_group && care_keys.size() + keys_by_group[g].size() <= 7) partners.push_back(g);
        std::stable_sort(partners.begin(), partners.end(), [&](int left, int right) {
            return std::make_pair(!preferred[left], std::abs(care_center - center(left)))
                < std::make_pair(!preferred[right], std::abs(care_center - center(right)));
        });
        if (partners.size() > static_cast<size_t>(partner_cap)) partners.resize(partner_cap);
        for (int ordinary_group : partners) {
            if (expired()) break;
            const auto& ordinary_keys = keys_by_group[ordinary_group];
            auto joint = care_keys;
            joint.insert(joint.end(), ordinary_keys.begin(), ordinary_keys.end());
            std::vector<int> seats;
            double current = 0.0;
            for (int p : joint) { seats.push_back(state.passenger_to_seat[p]); current += individual(p, seats.back()); }
            current += compact(group_seats[care_group]);
            current += compact(group_seats[ordinary_group]);
            current += baseline_baby;
            double best = current;
            std::vector<int> best_assignment;
            AssignmentState external(problem);
            external.restore(state.save());
            // These groups contain no protection users; removing them exactly
            // excludes their occupied and SSR seats without changing blocks.
            for (int p : joint) external.remove(p);
            std::vector<int> permutation(joint.size());
            std::iota(permutation.begin(), permutation.end(), 0);
            do {
                if (expired()) break;
                auto proposal = state.passenger_to_seat;
                bool feasible = true;
                for (size_t i = 0; i < joint.size(); ++i) {
                    proposal[joint[i]] = seats[permutation[i]];
                    if (!external.rich_seat_feasible(joint[i], proposal[joint[i]])) { feasible = false; break; }
                }
                if (!feasible) continue;
                for (int p : care_keys) {
                    if (!requires_care(p)) continue;
                    const auto rule = problem.ssr_rules.find(problem.passengers[p].ssr);
                    const bool cross = rule != problem.ssr_rules.end() && rule->second.caregiver_allow_cross_aisle;
                    const auto& seat = problem.seats[proposal[p]];
                    const auto& neighbors = cross ? seat.row_neighbors : seat.same_block_neighbors;
                    if (!std::any_of(care_keys.begin(), care_keys.end(), [&](int other) {
                        return other != p && problem.passengers[other].ssr.empty()
                            && std::find(neighbors.begin(), neighbors.end(), proposal[other]) != neighbors.end();
                    })) { feasible = false; break; }
                }
                if (!feasible) continue;
                double value = 0.0;
                for (int p : joint) value += individual(p, proposal[p]);
                for (int g : {care_group, ordinary_group}) {
                    std::vector<int> group_seat_list;
                    for (int p : keys_by_group[g]) group_seat_list.push_back(proposal[p]);
                    value += compact(group_seat_list);
                }
                value += baby_score(proposal);
                ++diagnostics.evaluated_moves;
                if (value > best + problem.rich.local_search_epsilon) { best = value; best_assignment = std::move(proposal); }
            } while (std::next_permutation(permutation.begin(), permutation.end()));
            if (best_assignment.empty()) continue;
            const auto snapshot = state.save();
            for (int p : joint) state.remove(p);
            auto submission = joint;
            std::stable_sort(submission.begin(), submission.end(), [&](int left, int right) { return requires_care(left) < requires_care(right); });
            bool committed = true;
            for (int p : submission) if (!state.assign(p, best_assignment[p])) { committed = false; break; }
            if (!committed) {
                for (int p : joint) state.remove(p);
                for (int p : submission) state.assign(p, snapshot.passenger_to_seat[p]);
                continue;
            }
            for (int g : {care_group, ordinary_group}) {
                group_seats[g].clear();
                for (int p : keys_by_group[g]) group_seats[g].push_back(state.passenger_to_seat[p]);
            }
            baseline_baby = baby_score(state.passenger_to_seat);
            ++diagnostics.accepted_moves;
            ++diagnostics.caregiver_rebuilds;
            diagnostics.score_improvement += best - current;
            break;
        }
    }
    diagnostics.stopped_by_deadline = expired();
    return diagnostics;
}

}  // namespace full_cpp
